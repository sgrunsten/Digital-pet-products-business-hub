# Google Analytics 4 Setup — Pet Owners Dream

## ✅ Setup Complete

The GA4 property and web data stream were successfully created.

## Key Deliverable

**Measurement ID: `G-03EHRJGZDM`**

## Details

| Field | Value |
|-------|-------|
| Account name | Pet Owners Dream |
| Property name | Pet Owners Dream |
| Reporting time zone | United States (GMT-07:00 Los Angeles Time) |
| Currency | US Dollar ($) |
| Industry category | Shopping |
| Business size | Small (1–10 employees) |
| Business objective | Drive sales |
| Stream name | Pet Owners Dream Web |
| Stream URL | https://petownersdream.com |
| Stream ID | 15225615447 |
| **Measurement ID** | **G-03EHRJGZDM** |

## Google Tag (gtag.js) snippet

```html
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-03EHRJGZDM"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-03EHRJGZDM');
</script>
```

## Proof

![Web stream details](screenshots/screenshot_1783569988492.png)
