import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Admin user
  const hashedPassword = await bcrypt.hash('johndoe123', 12);
  await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      name: 'Admin',
      password: hashedPassword,
      role: 'admin',
    },
  });

  // Sample products
  const products = [
    {
      title: 'Ultimate Pet Nutrition Guide',
      slug: 'ultimate-pet-nutrition-guide',
      description: 'A comprehensive 200-page ebook covering everything you need to know about feeding your dog or cat for optimal health. Learn about raw diets, commercial food analysis, home-cooked recipes, supplements, and age-specific nutritional needs.\n\nIncludes:\n- 50+ healthy pet recipes\n- Ingredient safety chart\n- Feeding schedule templates\n- Supplement guide',
      shortDescription: 'Complete nutrition guide with 50+ recipes for dogs and cats',
      price: 29.99,
      compareAtPrice: 49.99,
      category: 'ebooks',
      productType: 'ebook',
      imageUrl: 'https://cdn.abacus.ai/images/b8d13b5f-11d3-413a-9b05-73efb5f98fcb.png',
      featured: true,
      active: true,
    },
    {
      title: 'Dog Training Masterclass',
      slug: 'dog-training-masterclass',
      description: 'A step-by-step online course covering basic obedience, advanced tricks, behavior correction, and socialization. Includes 40+ video lessons taught by certified dog trainers with over 20 years of experience.\n\nTopics covered:\n- Basic commands (sit, stay, come, heel)\n- Leash training\n- Crate training\n- Socialization techniques\n- Problem behavior solutions',
      shortDescription: '40+ video lessons from certified dog trainers',
      price: 79.99,
      compareAtPrice: 149.99,
      category: 'courses',
      productType: 'course',
      imageUrl: 'https://cdn.abacus.ai/images/e18bd8da-caa5-4980-be38-94a3664d0569.png',
      featured: true,
      active: true,
    },
    {
      title: 'Pet Social Media Templates',
      slug: 'pet-social-media-templates',
      description: 'A collection of 100+ professionally designed social media templates perfect for pet businesses, pet influencers, and pet-loving content creators. Fully editable in Canva with drag-and-drop simplicity.\n\nIncludes templates for:\n- Instagram posts and stories\n- Facebook covers and posts\n- Pinterest pins\n- TikTok thumbnails',
      shortDescription: '100+ editable Canva templates for pet businesses',
      price: 39.99,
      compareAtPrice: null,
      category: 'templates',
      productType: 'template',
      imageUrl: 'https://cdn.abacus.ai/images/e3a4ae26-de2b-44ea-8698-6172ae618363.png',
      featured: true,
      active: true,
    },
    {
      title: 'Pet Health Tracker App',
      slug: 'pet-health-tracker-app',
      description: 'A digital pet health tracking spreadsheet and app template to monitor your pet\'s health, vaccinations, medications, vet visits, weight, and diet. Keep all your pet\'s health records organized in one place.\n\nFeatures:\n- Vaccination tracker\n- Weight log with charts\n- Medication reminders\n- Vet visit history\n- Diet and exercise log',
      shortDescription: 'Digital health tracking system for your pets',
      price: 19.99,
      compareAtPrice: 34.99,
      category: 'software',
      productType: 'software',
      imageUrl: 'https://cdn.abacus.ai/images/bb30c4a2-29f1-41ef-9938-7d3f2a6c79e9.png',
      featured: false,
      active: true,
    },
    {
      title: 'Pet Portrait Illustration Pack',
      slug: 'pet-portrait-illustration-pack',
      description: 'A beautiful collection of 50+ hand-drawn pet portrait illustrations in various styles. Perfect for print-on-demand products, social media, websites, and personal projects.\n\nIncludes:\n- Dog breeds (30+ varieties)\n- Cat breeds (15+ varieties)\n- Rabbits, hamsters, and birds\n- PNG and SVG formats\n- Commercial license included',
      shortDescription: '50+ hand-drawn pet illustrations with commercial license',
      price: 24.99,
      compareAtPrice: null,
      category: 'graphics',
      productType: 'graphic',
      imageUrl: 'https://cdn.abacus.ai/images/3e860020-1efd-467a-8fa7-5114b93444ae.png',
      featured: false,
      active: true,
    },
    {
      title: 'Puppy Care Video Series',
      slug: 'puppy-care-video-series',
      description: 'Everything you need to know about raising a happy, healthy puppy from day one. This 12-episode video series covers the first year of puppy ownership with expert veterinary advice.\n\nEpisodes include:\n- Bringing puppy home\n- Puppy-proofing your space\n- First vet visits\n- Housebreaking tips\n- Teething and chewing solutions\n- Socialization windows',
      shortDescription: '12-episode video series on raising a healthy puppy',
      price: 49.99,
      compareAtPrice: 89.99,
      category: 'videos',
      productType: 'video',
      imageUrl: 'https://cdn.abacus.ai/images/670567db-7ff9-470a-8f1f-3e312928e444.png',
      featured: true,
      active: true,
    },
    {
      title: 'Cat Behavior Audio Guide',
      slug: 'cat-behavior-audio-guide',
      description: 'A 6-hour audio course that helps you understand your cat\'s body language, vocalizations, and behavior patterns. Learn to build a stronger bond with your feline companion.\n\nTopics covered:\n- Decoding cat body language\n- Understanding meows and purrs\n- Territory and marking behavior\n- Play and hunting instincts\n- Multi-cat household harmony',
      shortDescription: '6-hour audio course on understanding cat behavior',
      price: 34.99,
      compareAtPrice: null,
      category: 'audio',
      productType: 'audio',
      imageUrl: 'https://cdn.abacus.ai/images/87f088de-2581-4bfc-a2c1-f178bf8a4d51.png',
      featured: false,
      active: true,
    },
    {
      title: 'Pet Business Startup Kit',
      slug: 'pet-business-startup-kit',
      description: 'Launch your pet business with confidence using this comprehensive startup kit. Includes business plan templates, financial projections, marketing strategies, and legal documents tailored for pet industry entrepreneurs.\n\nContents:\n- Business plan template\n- Financial projection spreadsheets\n- Marketing calendar and strategies\n- Social media content planner\n- Client contracts and forms\n- Pricing calculator',
      shortDescription: 'Complete startup toolkit for pet industry entrepreneurs',
      price: 59.99,
      compareAtPrice: 99.99,
      category: 'templates',
      productType: 'template',
      imageUrl: 'https://cdn.abacus.ai/images/055b42fb-f428-47cb-9024-fede8f433596.png',
      featured: false,
      active: true,
    },
  ];

  for (const product of products) {
    await prisma.product.upsert({
      where: { slug: product.slug },
      update: {
        title: product.title,
        imageUrl: product.imageUrl,
        price: product.price,
        compareAtPrice: product.compareAtPrice,
        featured: product.featured,
      },
      create: product,
    });
  }

  // Sample discount codes
  await prisma.discountCode.upsert({
    where: { code: 'PETLOVE20' },
    update: {},
    create: {
      code: 'PETLOVE20',
      type: 'percentage',
      value: 20,
      minOrderAmount: 25,
      active: true,
    },
  });

  await prisma.discountCode.upsert({
    where: { code: 'WELCOME10' },
    update: {},
    create: {
      code: 'WELCOME10',
      type: 'fixed',
      value: 10,
      minOrderAmount: 30,
      maxUses: 100,
      active: true,
    },
  });

  console.log('Seeding complete!');
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
