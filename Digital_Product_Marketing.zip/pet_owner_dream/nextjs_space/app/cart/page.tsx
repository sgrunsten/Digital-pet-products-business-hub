'use client';

import Image from 'next/image';
import Link from 'next/link';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { Button } from '@/components/ui/button';
import { useCart } from '@/lib/cart-context';
import { formatPrice } from '@/lib/constants';
import { Trash2, ShoppingBag, ArrowRight, Package } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function CartPage() {
  const { items, removeItem, clearCart, subtotal } = useCart();

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="max-w-[800px] mx-auto px-4 py-8">
          <h1 className="font-display text-3xl font-bold tracking-tight mb-2">Shopping Cart</h1>
          <p className="text-muted-foreground mb-8">{items?.length ?? 0} item{(items?.length ?? 0) !== 1 ? 's' : ''} in your cart</p>

          {(items?.length ?? 0) > 0 ? (
            <>
              <div className="space-y-4">
                <AnimatePresence>
                  {(items ?? []).map((item: any) => (
                    <motion.div
                      key={item?.id}
                      layout
                      exit={{ opacity: 0, x: -100 }}
                      className="bg-card rounded-lg p-4 flex items-center gap-4"
                      style={{ boxShadow: 'var(--shadow-sm)' }}
                    >
                      <div className="relative w-20 h-14 rounded-md overflow-hidden bg-muted flex-shrink-0">
                        {item?.imageUrl ? (
                          <Image src={item.imageUrl} alt={item?.title ?? ''} fill className="object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center"><Package className="h-6 w-6 text-muted-foreground/30" /></div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold truncate">{item?.title ?? 'Untitled'}</h3>
                        <p className="text-sm text-muted-foreground">Digital download</p>
                      </div>
                      <p className="font-display font-bold text-lg">{formatPrice(item?.price ?? 0)}</p>
                      <Button variant="ghost" size="icon" onClick={() => removeItem?.(item?.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              <div className="mt-8 bg-card rounded-lg p-6" style={{ boxShadow: 'var(--shadow-md)' }}>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-display font-bold text-2xl">{formatPrice(subtotal ?? 0)}</span>
                </div>
                <div className="flex gap-3">
                  <Link href="/checkout" className="flex-1">
                    <Button size="lg" className="w-full gap-2">
                      Checkout <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Button variant="outline" size="lg" onClick={() => clearCart?.()}>Clear</Button>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-20">
              <ShoppingBag className="h-20 w-20 text-muted-foreground/20 mx-auto mb-4" />
              <h3 className="font-display text-xl font-semibold mb-2">Your cart is empty</h3>
              <p className="text-muted-foreground mb-6">Discover amazing digital products for your pet</p>
              <Link href="/products">
                <Button size="lg" className="gap-2">Browse Products <ArrowRight className="h-4 w-4" /></Button>
              </Link>
            </div>
          )}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
