export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const [totalOrders, totalRevenue, totalProducts, totalCustomers, recentOrders, topProducts, categoryStats, subscribers] = await Promise.all([
      prisma.order.count(),
      prisma.order.aggregate({ _sum: { total: true } }),
      prisma.product.count({ where: { active: true } }),
      prisma.order.findMany({ select: { customerEmail: true }, distinct: ['customerEmail'] }),
      prisma.order.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: { items: { include: { product: { select: { title: true } } } } },
      }),
      prisma.product.findMany({
        where: { active: true },
        orderBy: { downloadCount: 'desc' },
        take: 5,
        select: { id: true, title: true, price: true, downloadCount: true, category: true },
      }),
      prisma.product.groupBy({
        by: ['category'],
        where: { active: true },
        _count: { id: true },
        _sum: { downloadCount: true },
      }),
      prisma.emailSubscriber.count({ where: { active: true } }),
    ]);

    // Monthly revenue for chart
    const orders = await prisma.order.findMany({
      select: { total: true, createdAt: true },
      orderBy: { createdAt: 'asc' },
    });

    const monthlyRevenue: Record<string, number> = {};
    (orders ?? []).forEach((o: any) => {
      const month = new Date(o?.createdAt).toISOString().slice(0, 7);
      monthlyRevenue[month] = (monthlyRevenue[month] ?? 0) + (o?.total ?? 0);
    });

    const revenueChart = Object.entries(monthlyRevenue ?? {}).map(([month, revenue]) => ({
      month,
      revenue: Math.round((revenue ?? 0) * 100) / 100,
    }));

    return NextResponse.json({
      totalOrders: totalOrders ?? 0,
      totalRevenue: totalRevenue?._sum?.total ?? 0,
      totalProducts: totalProducts ?? 0,
      totalCustomers: totalCustomers?.length ?? 0,
      subscribers: subscribers ?? 0,
      recentOrders: recentOrders ?? [],
      topProducts: topProducts ?? [],
      categoryStats: categoryStats ?? [],
      revenueChart: revenueChart ?? [],
    });
  } catch (error: any) {
    console.error('Analytics error:', error);
    return NextResponse.json({ error: 'Failed to fetch analytics' }, { status: 500 });
  }
}
