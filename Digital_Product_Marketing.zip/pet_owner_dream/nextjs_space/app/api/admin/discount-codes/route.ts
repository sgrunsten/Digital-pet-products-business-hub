export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const codes = await prisma.discountCode.findMany({ orderBy: { createdAt: 'desc' } });
    return NextResponse.json(codes ?? []);
  } catch (error: any) {
    console.error('Discount codes GET error:', error);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const data = await request.json();
    const code = await prisma.discountCode.create({
      data: {
        code: (data?.code ?? '').toUpperCase(),
        type: data?.type ?? 'percentage',
        value: parseFloat(data?.value ?? '0'),
        minOrderAmount: data?.minOrderAmount ? parseFloat(data.minOrderAmount) : 0,
        maxUses: data?.maxUses ? parseInt(data.maxUses) : null,
        active: data?.active ?? true,
        expiresAt: data?.expiresAt ? new Date(data.expiresAt) : null,
      },
    });
    return NextResponse.json(code);
  } catch (error: any) {
    console.error('Discount create error:', error);
    return NextResponse.json({ error: 'Failed to create discount' }, { status: 500 });
  }
}
