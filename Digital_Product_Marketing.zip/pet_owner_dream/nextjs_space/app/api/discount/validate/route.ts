export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { code, subtotal } = await request.json();
    if (!code) return NextResponse.json({ error: 'Code required' }, { status: 400 });

    const discount = await prisma.discountCode.findUnique({
      where: { code: code.toUpperCase() },
    });

    if (!discount || !discount.active) {
      return NextResponse.json({ error: 'Invalid discount code', valid: false }, { status: 400 });
    }

    if (discount.expiresAt && new Date() > new Date(discount.expiresAt)) {
      return NextResponse.json({ error: 'Discount code has expired', valid: false }, { status: 400 });
    }

    if (discount.maxUses && discount.usedCount >= discount.maxUses) {
      return NextResponse.json({ error: 'Discount code usage limit reached', valid: false }, { status: 400 });
    }

    if (discount.minOrderAmount && (subtotal ?? 0) < discount.minOrderAmount) {
      return NextResponse.json({ error: `Minimum order amount is $${discount.minOrderAmount}`, valid: false }, { status: 400 });
    }

    let discountAmount = 0;
    if (discount.type === 'percentage') {
      discountAmount = ((subtotal ?? 0) * discount.value) / 100;
    } else {
      discountAmount = discount.value;
    }

    return NextResponse.json({
      valid: true,
      discountAmount: Math.min(discountAmount, subtotal ?? 0),
      type: discount.type,
      value: discount.value,
    });
  } catch (error: any) {
    console.error('Discount validate error:', error);
    return NextResponse.json({ error: 'Validation failed', valid: false }, { status: 500 });
  }
}
