export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { prisma } from '@/lib/db';
import { generateOrderNumber } from '@/lib/constants';

export async function POST(request: Request) {
  try {
    const data = await request.json();
    if (!data?.email?.trim()) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }
    if (!data?.items?.length) {
      return NextResponse.json({ error: 'No items in order' }, { status: 400 });
    }

    const origin = request.headers.get('origin') || process.env.NEXTAUTH_URL || '';

    // Fetch products to get accurate prices and titles
    const productIds = data.items.map((i: any) => i?.productId).filter(Boolean);
    const products = await prisma.product.findMany({
      where: { id: { in: productIds }, active: true },
    });

    if (products.length === 0) {
      return NextResponse.json({ error: 'No valid products found' }, { status: 400 });
    }

    const subtotal = products.reduce((s: number, p: any) => s + (p?.price ?? 0), 0);
    let discountAmount = 0;
    let validDiscountCode: string | null = null;

    // Validate discount code if provided
    if (data?.discountCode) {
      const dc = await prisma.discountCode.findFirst({
        where: {
          code: data.discountCode,
          active: true,
          OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
        },
      });
      if (dc && (dc.maxUses === null || dc.usedCount < (dc.maxUses ?? Infinity))) {
        if (dc.type === 'percentage') {
          discountAmount = Math.round(subtotal * (dc.value / 100) * 100) / 100;
        } else {
          discountAmount = Math.min(dc.value, subtotal);
        }
        validDiscountCode = dc.code;
      }
    }

    const total = Math.max(0, subtotal - discountAmount);
    const orderNumber = generateOrderNumber();

    // Create pending order
    const order = await prisma.order.create({
      data: {
        orderNumber,
        customerEmail: data.email,
        customerName: data?.name ?? null,
        status: 'pending',
        subtotal,
        discount: discountAmount,
        total,
        discountCode: validDiscountCode,
        items: {
          create: products.map((p: any) => ({
            productId: p.id,
            quantity: 1,
            price: p.price,
          })),
        },
      },
    });

    // Build Stripe line items
    const lineItems = products.map((p: any) => ({
      price_data: {
        currency: 'usd',
        product_data: {
          name: p.title || 'Digital Product',
          description: p.shortDescription || p.category || 'Digital download',
        },
        unit_amount: Math.round((p.price ?? 0) * 100),
      },
      quantity: 1,
    }));

    // Add discount as a coupon if applicable
    const discounts: any[] = [];
    if (discountAmount > 0) {
      const coupon = await stripe.coupons.create({
        amount_off: Math.round(discountAmount * 100),
        currency: 'usd',
        duration: 'once',
        name: validDiscountCode || 'Discount',
      });
      discounts.push({ coupon: coupon.id });
    }

    // Create Stripe Checkout Session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      customer_email: data.email,
      line_items: lineItems,
      discounts: discounts.length > 0 ? discounts : undefined,
      metadata: {
        orderNumber,
        orderId: order.id,
        discountCode: validDiscountCode || '',
      },
      success_url: `${origin}/order-confirmation/${orderNumber}?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/checkout?cancelled=true`,
    });

    // Save Stripe session ID to order
    await prisma.order.update({
      where: { id: order.id },
      data: { stripeSessionId: session.id },
    });

    return NextResponse.json({ url: session.url, orderNumber });
  } catch (error: any) {
    console.error('Stripe checkout error:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to create checkout session' },
      { status: 500 }
    );
  }
}
