export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { SOCIAL_PLATFORMS } from '@/lib/constants';
import { uploadBufferToS3 } from '@/lib/s3';

const LLM_BASE = 'https://routellm.abacus.ai/v1/chat/completions';

type PlatformResult = {
  platform: string;
  content: string;
  hashtags: string;
  charLimit: number;
};

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { productId, platforms, tone, generateImage } = body as {
      productId: string;
      platforms: string[];
      tone?: string;
      generateImage?: boolean;
    };

    if (!productId || !Array.isArray(platforms) || platforms.length === 0) {
      return NextResponse.json(
        { error: 'productId and at least one platform are required.' },
        { status: 400 }
      );
    }

    const product = await prisma.product.findUnique({ where: { id: productId } });
    if (!product) {
      return NextResponse.json({ error: 'Product not found.' }, { status: 404 });
    }

    const apiKey = process.env.ABACUSAI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'Content generation is not configured.' },
        { status: 500 }
      );
    }

    const selected = SOCIAL_PLATFORMS.filter((p) => platforms.includes(p.value));
    const platformSpec = selected
      .map(
        (p) =>
          `- ${p.label} (key: "${p.value}", max ${p.charLimit} characters): ${p.tip}`
      )
      .join('\n');

    const toneText = tone && tone.trim() ? tone.trim() : 'friendly, warm, and helpful';

    const systemPrompt =
      'You are an expert social media marketer for a pet-products brand called "Pet Owners Dream". ' +
      'You write high-converting, platform-optimized captions. Always respect each platform character limit. ' +
      'Return ONLY valid JSON, no markdown fences.';

    const userPrompt = `Create social media posts promoting this digital product.

Product title: ${product.title}
Category: ${product.category}
Price: $${product.price.toFixed(2)}
Short description: ${product.shortDescription ?? ''}
Full description: ${product.description}

Tone: ${toneText}

Generate one post per platform below. Stay within each character limit for the "content" field (excluding hashtags):
${platformSpec}

Return JSON in EXACTLY this shape:
{
  "posts": [
    { "platform": "<platform key>", "content": "<caption text>", "hashtags": "#tag1 #tag2 #tag3" }
  ]
}`;

    const llmRes = await fetch(LLM_BASE, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-5.4-mini',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        response_format: { type: 'json_object' },
        temperature: 0.8,
      }),
    });

    if (!llmRes.ok) {
      const errText = await llmRes.text();
      console.error('LLM generation failed:', llmRes.status, errText);
      return NextResponse.json(
        { error: 'Failed to generate content. Please try again.' },
        { status: 502 }
      );
    }

    const llmData = await llmRes.json();
    const raw = llmData?.choices?.[0]?.message?.content ?? '{}';
    let parsed: { posts?: Array<{ platform: string; content: string; hashtags: string }> };
    try {
      parsed = JSON.parse(raw);
    } catch {
      const match = raw.match(/\{[\s\S]*\}/);
      parsed = match ? JSON.parse(match[0]) : { posts: [] };
    }

    const posts: PlatformResult[] = (parsed.posts ?? []).map((post) => {
      const spec = SOCIAL_PLATFORMS.find((p) => p.value === post.platform);
      return {
        platform: post.platform,
        content: post.content ?? '',
        hashtags: post.hashtags ?? '',
        charLimit: spec?.charLimit ?? 2200,
      };
    });

    // Optionally generate a single promo image reused across platforms.
    let imageUrl: string | null = null;
    if (generateImage) {
      try {
        const imgPrompt = `A vibrant, professional social media promotional image for a pet product called "${product.title}". Category: ${product.category}. Clean modern design, appealing to pet owners, bright and eye-catching, no text overlay.`;
        const imgRes = await fetch(LLM_BASE, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model: 'gpt-5.1',
            messages: [{ role: 'user', content: imgPrompt }],
            modalities: ['image'],
          }),
        });
        if (imgRes.ok) {
          const imgData = await imgRes.json();
          const dataUrl: string | undefined =
            imgData?.choices?.[0]?.message?.images?.[0]?.image_url?.url ??
            imgData?.choices?.[0]?.message?.images?.[0]?.url;
          if (dataUrl && dataUrl.startsWith('data:')) {
            const base64 = dataUrl.split(',')[1];
            const contentType = dataUrl.substring(5, dataUrl.indexOf(';'));
            const ext = contentType.split('/')[1] ?? 'png';
            const buffer = Buffer.from(base64, 'base64');
            const safeSlug = product.slug.replace(/[^a-z0-9]/gi, '-').toLowerCase();
            const uploaded = await uploadBufferToS3(
              buffer,
              contentType,
              `${safeSlug}.${ext}`
            );
            imageUrl = uploaded.publicUrl;
          }
        } else {
          console.error('Image generation failed:', imgRes.status, await imgRes.text());
        }
      } catch (err) {
        console.error('Image generation error:', err);
      }
    }

    return NextResponse.json({
      productId: product.id,
      productTitle: product.title,
      posts,
      imageUrl,
    });
  } catch (err) {
    console.error('Social generate error:', err);
    return NextResponse.json({ error: 'Something went wrong.' }, { status: 500 });
  }
}
