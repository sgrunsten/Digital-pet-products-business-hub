export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const posts = await prisma.socialPost.findMany({
      orderBy: [{ scheduledFor: 'asc' }, { createdAt: 'desc' }],
    });

    return NextResponse.json({ posts });
  } catch (err) {
    console.error('Fetch social posts error:', err);
    return NextResponse.json({ error: 'Failed to load posts.' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { productId, productTitle, platform, content, hashtags, imageUrl, scheduledFor, status } =
      body as {
        productId?: string;
        productTitle?: string;
        platform: string;
        content: string;
        hashtags?: string;
        imageUrl?: string;
        scheduledFor?: string | null;
        status?: string;
      };

    if (!platform || !content) {
      return NextResponse.json(
        { error: 'platform and content are required.' },
        { status: 400 }
      );
    }

    const post = await prisma.socialPost.create({
      data: {
        productId: productId ?? null,
        productTitle: productTitle ?? null,
        platform,
        content,
        hashtags: hashtags ?? '',
        imageUrl: imageUrl ?? null,
        scheduledFor: scheduledFor ? new Date(scheduledFor) : null,
        status: status ?? (scheduledFor ? 'scheduled' : 'draft'),
      },
    });

    return NextResponse.json({ post });
  } catch (err) {
    console.error('Create social post error:', err);
    return NextResponse.json({ error: 'Failed to save post.' }, { status: 500 });
  }
}
