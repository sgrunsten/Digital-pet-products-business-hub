export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { content, hashtags, imageUrl, scheduledFor, status } = body as {
      content?: string;
      hashtags?: string;
      imageUrl?: string | null;
      scheduledFor?: string | null;
      status?: string;
    };

    const data: Record<string, unknown> = {};
    if (content !== undefined) data.content = content;
    if (hashtags !== undefined) data.hashtags = hashtags;
    if (imageUrl !== undefined) data.imageUrl = imageUrl;
    if (scheduledFor !== undefined) {
      data.scheduledFor = scheduledFor ? new Date(scheduledFor) : null;
    }
    if (status !== undefined) data.status = status;

    const post = await prisma.socialPost.update({
      where: { id: params.id },
      data,
    });

    return NextResponse.json({ post });
  } catch (err) {
    console.error('Update social post error:', err);
    return NextResponse.json({ error: 'Failed to update post.' }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await prisma.socialPost.delete({ where: { id: params.id } });
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error('Delete social post error:', err);
    return NextResponse.json({ error: 'Failed to delete post.' }, { status: 500 });
  }
}
