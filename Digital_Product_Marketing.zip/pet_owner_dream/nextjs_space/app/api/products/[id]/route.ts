export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const product = await prisma.product.findUnique({ where: { id: params?.id ?? '' } });
    if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json(product);
  } catch (error: any) {
    console.error('Product GET error:', error);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const data = await request.json();
    const updateData: any = {};

    if (data?.title !== undefined) updateData.title = data.title;
    if (data?.description !== undefined) updateData.description = data.description;
    if (data?.shortDescription !== undefined) updateData.shortDescription = data.shortDescription;
    if (data?.price !== undefined) updateData.price = parseFloat(data.price);
    if (data?.compareAtPrice !== undefined) updateData.compareAtPrice = data.compareAtPrice ? parseFloat(data.compareAtPrice) : null;
    if (data?.category !== undefined) updateData.category = data.category;
    if (data?.productType !== undefined) updateData.productType = data.productType;
    if (data?.imageUrl !== undefined) updateData.imageUrl = data.imageUrl;
    if (data?.galleryImages !== undefined) updateData.galleryImages = data.galleryImages;
    if (data?.filePath !== undefined) updateData.filePath = data.filePath;
    if (data?.fileIsPublic !== undefined) updateData.fileIsPublic = data.fileIsPublic;
    if (data?.fileName !== undefined) updateData.fileName = data.fileName;
    if (data?.fileSize !== undefined) updateData.fileSize = data.fileSize ? parseInt(data.fileSize) : null;
    if (data?.featured !== undefined) updateData.featured = data.featured;
    if (data?.active !== undefined) updateData.active = data.active;

    const product = await prisma.product.update({ where: { id: params?.id ?? '' }, data: updateData });
    return NextResponse.json(product);
  } catch (error: any) {
    console.error('Product update error:', error);
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    await prisma.product.update({ where: { id: params?.id ?? '' }, data: { active: false } });
    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Product delete error:', error);
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
  }
}
