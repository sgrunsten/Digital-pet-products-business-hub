export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const category = url.searchParams.get('category');
    const featured = url.searchParams.get('featured');
    const active = url.searchParams.get('active');

    const where: any = {};
    if (category) where.category = category;
    if (featured === 'true') where.featured = true;
    if (active !== 'all') where.active = true;

    const products = await prisma.product.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(products ?? []);
  } catch (error: any) {
    console.error('Products GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const data = await request.json();
    const slug = (data?.title ?? 'product')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') + '-' + Date.now().toString(36);

    const product = await prisma.product.create({
      data: {
        title: data?.title ?? 'Untitled',
        slug,
        description: data?.description ?? '',
        shortDescription: data?.shortDescription ?? null,
        price: parseFloat(data?.price ?? '0'),
        compareAtPrice: data?.compareAtPrice ? parseFloat(data.compareAtPrice) : null,
        category: data?.category ?? 'ebooks',
        productType: data?.productType ?? 'ebook',
        imageUrl: data?.imageUrl ?? null,
        galleryImages: data?.galleryImages ?? [],
        filePath: data?.filePath ?? null,
        fileIsPublic: data?.fileIsPublic ?? false,
        fileName: data?.fileName ?? null,
        fileSize: data?.fileSize ? parseInt(data.fileSize) : null,
        featured: data?.featured ?? false,
        active: data?.active ?? true,
      },
    });

    return NextResponse.json(product);
  } catch (error: any) {
    console.error('Product create error:', error);
    return NextResponse.json({ error: 'Failed to create product' }, { status: 500 });
  }
}
