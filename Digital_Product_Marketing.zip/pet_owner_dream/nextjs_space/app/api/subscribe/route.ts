export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { email, name } = await request.json();
    if (!email?.trim()) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }

    await prisma.emailSubscriber.upsert({
      where: { email: email.toLowerCase() },
      update: { active: true, name: name ?? undefined },
      create: { email: email.toLowerCase(), name: name ?? null },
    });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Subscribe error:', error);
    return NextResponse.json({ error: 'Subscription failed' }, { status: 500 });
  }
}
