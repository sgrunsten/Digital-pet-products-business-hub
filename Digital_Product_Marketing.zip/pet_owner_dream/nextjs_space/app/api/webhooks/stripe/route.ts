export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { prisma } from '@/lib/db';

export async function POST(request: Request) {
  const body = await request.text();
  const sig = request.headers.get('stripe-signature');

  // If webhook secret is configured, verify the signature
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event;
  try {
    if (webhookSecret && sig) {
      event = stripe.webhooks.constructEvent(body, sig, webhookSecret);
    } else {
      // For development without webhook secret, parse directly
      event = JSON.parse(body);
    }
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err?.message);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  try {
    if (event.type === 'checkout.session.completed') {
      const session = event.data?.object;
      const orderNumber = session?.metadata?.orderNumber;
      const orderId = session?.metadata?.orderId;

      if (orderNumber) {
        // Update order status
        const order = await prisma.order.update({
          where: { orderNumber },
          data: {
            status: 'completed',
            stripePaymentId: session?.payment_intent ?? null,
          },
          include: { items: true },
        });

        // Create download tokens
        const downloadPromises = (order?.items ?? []).map((item: any) =>
          prisma.download.create({
            data: {
              token: `${orderNumber}-${item?.productId ?? ''}-${Math.random().toString(36).substring(2, 10)}`,
              orderId: order.id,
              productId: item?.productId ?? '',
              expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
              maxDownloads: 5,
            },
          })
        );
        await Promise.all(downloadPromises);

        // Update discount code usage
        const discountCode = session?.metadata?.discountCode;
        if (discountCode) {
          await prisma.discountCode.updateMany({
            where: { code: discountCode, active: true },
            data: { usedCount: { increment: 1 } },
          });
        }

        // Update product download counts
        for (const item of order?.items ?? []) {
          await prisma.product.update({
            where: { id: item?.productId ?? '' },
            data: { downloadCount: { increment: 1 } },
          });
        }

        // Send notification emails
        await sendOrderEmails(order, session?.customer_email ?? '', orderNumber);
      }
    }

    return NextResponse.json({ received: true });
  } catch (error: any) {
    console.error('Webhook processing error:', error);
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 });
  }
}

async function sendOrderEmails(order: any, email: string, orderNumber: string) {
  try {
    const items = await prisma.orderItem.findMany({
      where: { orderId: order?.id ?? '' },
      include: { product: { select: { title: true } } },
    });

    const itemsHtml = (items ?? []).map((item: any) =>
      `<tr><td style="padding:8px;border-bottom:1px solid #eee">${item?.product?.title ?? 'Product'}</td><td style="padding:8px;border-bottom:1px solid #eee;text-align:right">$${(item?.price ?? 0).toFixed(2)}</td></tr>`
    ).join('');

    const appUrl = process.env.NEXTAUTH_URL ?? '';
    const appName = 'Pet Owners Dream';

    const htmlBody = `
      <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
        <div style="background:linear-gradient(135deg,#f59e0b,#ea580c);padding:24px;border-radius:8px 8px 0 0;text-align:center">
          <h1 style="color:#fff;margin:0">🐾 Order Confirmed!</h1>
        </div>
        <div style="padding:24px;background:#fff;border:1px solid #eee">
          <p>Thank you for your purchase! Your digital products are ready for download.</p>
          <p><strong>Order Number:</strong> ${orderNumber}</p>
          <table style="width:100%;border-collapse:collapse;margin:16px 0">
            <thead><tr><th style="text-align:left;padding:8px;border-bottom:2px solid #f59e0b">Product</th><th style="text-align:right;padding:8px;border-bottom:2px solid #f59e0b">Price</th></tr></thead>
            <tbody>${itemsHtml}</tbody>
            <tfoot><tr><td style="padding:8px;font-weight:bold">Total</td><td style="padding:8px;font-weight:bold;text-align:right">$${(order?.total ?? 0).toFixed(2)}</td></tr></tfoot>
          </table>
          <div style="text-align:center;margin:24px 0">
            <a href="${appUrl}/order-confirmation/${orderNumber}" style="background:#f59e0b;color:#fff;padding:12px 32px;text-decoration:none;border-radius:6px;font-weight:bold">Download Your Products</a>
          </div>
          <p style="color:#666;font-size:12px">Download links expire in 30 days. Maximum 5 downloads per product.</p>
        </div>
      </div>
    `;

    await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_ORDER_CONFIRMATION,
        subject: `Order Confirmed: ${orderNumber} 🐾`,
        body: htmlBody,
        is_html: true,
        recipient_email: email,
        sender_email: `noreply@${appUrl ? new URL(appUrl).hostname : 'petownersdream.com'}`,
        sender_alias: appName,
      }),
    });

    await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_NEW_ORDER_ALERT,
        subject: `New Order: ${orderNumber} - $${(order?.total ?? 0).toFixed(2)}`,
        body: `<div style="font-family:Arial,sans-serif"><h2>New Order Received</h2><p><strong>Order:</strong> ${orderNumber}</p><p><strong>Customer:</strong> ${email}</p><p><strong>Total:</strong> $${(order?.total ?? 0).toFixed(2)}</p></div>`,
        is_html: true,
        sender_email: `noreply@${appUrl ? new URL(appUrl).hostname : 'petownersdream.com'}`,
        sender_alias: appName,
      }),
    });
  } catch (err: any) {
    console.error('Email send error:', err);
  }
}
