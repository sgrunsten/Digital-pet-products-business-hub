export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { generateOrderNumber } from '@/lib/constants';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const orders = await prisma.order.findMany({
      include: { items: { include: { product: { select: { title: true, category: true } } } } },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(orders ?? []);
  } catch (error: any) {
    console.error('Orders GET error:', error);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json();
    if (!data?.email?.trim()) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }
    if (!data?.items?.length) {
      return NextResponse.json({ error: 'No items in order' }, { status: 400 });
    }

    const subtotal = (data.items ?? []).reduce((s: number, i: any) => s + (i?.price ?? 0), 0);
    const discountAmount = data?.discount ?? 0;
    const total = Math.max(0, subtotal - discountAmount);
    const orderNumber = generateOrderNumber();

    // Create order with items
    const order = await prisma.order.create({
      data: {
        orderNumber,
        customerEmail: data.email,
        customerName: data?.name ?? null,
        status: 'completed',
        subtotal,
        discount: discountAmount,
        total,
        discountCode: data?.discountCode ?? null,
        items: {
          create: (data.items ?? []).map((item: any) => ({
            productId: item?.productId ?? '',
            quantity: item?.quantity ?? 1,
            price: item?.price ?? 0,
          })),
        },
      },
      include: { items: true },
    });

    // Create download tokens
    const downloadPromises = (order?.items ?? []).map((item: any) =>
      prisma.download.create({
        data: {
          token: `${orderNumber}-${item?.productId ?? ''}-${Math.random().toString(36).substring(2, 10)}`,
          orderId: order.id,
          productId: item?.productId ?? '',
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
          maxDownloads: 5,
        },
      })
    );
    await Promise.all(downloadPromises);

    // Update discount code usage
    if (data?.discountCode) {
      await prisma.discountCode.updateMany({
        where: { code: data.discountCode, active: true },
        data: { usedCount: { increment: 1 } },
      });
    }

    // Update product download counts
    for (const item of order?.items ?? []) {
      await prisma.product.update({
        where: { id: item?.productId ?? '' },
        data: { downloadCount: { increment: 1 } },
      });
    }

    // Send order confirmation email (non-blocking)
    sendOrderConfirmationEmail(order, data.email, orderNumber).catch((err: any) => console.error('Email error:', err));

    return NextResponse.json({ success: true, orderNumber, orderId: order?.id });
  } catch (error: any) {
    console.error('Order create error:', error);
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 });
  }
}

async function sendOrderConfirmationEmail(order: any, email: string, orderNumber: string) {
  try {
    const items = await prisma.orderItem.findMany({
      where: { orderId: order?.id ?? '' },
      include: { product: { select: { title: true } } },
    });

    const itemsHtml = (items ?? []).map((item: any) =>
      `<tr><td style="padding:8px;border-bottom:1px solid #eee">${item?.product?.title ?? 'Product'}</td><td style="padding:8px;border-bottom:1px solid #eee;text-align:right">$${(item?.price ?? 0).toFixed(2)}</td></tr>`
    ).join('');

    const appUrl = process.env.NEXTAUTH_URL ?? '';
    const appName = 'Pet Owners Dream';

    const htmlBody = `
      <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
        <div style="background:linear-gradient(135deg,#f59e0b,#ea580c);padding:24px;border-radius:8px 8px 0 0;text-align:center">
          <h1 style="color:#fff;margin:0">🐾 Order Confirmed!</h1>
        </div>
        <div style="padding:24px;background:#fff;border:1px solid #eee">
          <p>Thank you for your purchase! Your digital products are ready for download.</p>
          <p><strong>Order Number:</strong> ${orderNumber}</p>
          <table style="width:100%;border-collapse:collapse;margin:16px 0">
            <thead><tr><th style="text-align:left;padding:8px;border-bottom:2px solid #f59e0b">Product</th><th style="text-align:right;padding:8px;border-bottom:2px solid #f59e0b">Price</th></tr></thead>
            <tbody>${itemsHtml}</tbody>
            <tfoot><tr><td style="padding:8px;font-weight:bold">Total</td><td style="padding:8px;font-weight:bold;text-align:right">$${(order?.total ?? 0).toFixed(2)}</td></tr></tfoot>
          </table>
          <div style="text-align:center;margin:24px 0">
            <a href="${appUrl}/order-confirmation/${orderNumber}" style="background:#f59e0b;color:#fff;padding:12px 32px;text-decoration:none;border-radius:6px;font-weight:bold">Download Your Products</a>
          </div>
          <p style="color:#666;font-size:12px">Download links expire in 30 days. Maximum 5 downloads per product.</p>
        </div>
      </div>
    `;

    await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_ORDER_CONFIRMATION,
        subject: `Order Confirmed: ${orderNumber} 🐾`,
        body: htmlBody,
        is_html: true,
        recipient_email: email,
        sender_email: `noreply@${appUrl ? new URL(appUrl).hostname : 'petownerdream.com'}`,
        sender_alias: appName,
      }),
    });

    // Also notify admin
    await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_NEW_ORDER_ALERT,
        subject: `New Order: ${orderNumber} - $${(order?.total ?? 0).toFixed(2)}`,
        body: `<div style="font-family:Arial,sans-serif"><h2>New Order Received</h2><p><strong>Order:</strong> ${orderNumber}</p><p><strong>Customer:</strong> ${email}</p><p><strong>Total:</strong> $${(order?.total ?? 0).toFixed(2)}</p></div>`,
        is_html: true,
        recipient_email: 'sgrunsten@gmail.com',
        sender_email: `noreply@${appUrl ? new URL(appUrl).hostname : 'petownerdream.com'}`,
        sender_alias: appName,
      }),
    });
  } catch (err: any) {
    console.error('Email send error:', err);
  }
}
