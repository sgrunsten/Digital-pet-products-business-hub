export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getFileUrl } from '@/lib/s3';

export async function GET(request: Request, { params }: { params: { token: string } }) {
  try {
    const download = await prisma.download.findUnique({
      where: { token: params?.token ?? '' },
    });

    if (!download) {
      return NextResponse.json({ error: 'Invalid download link' }, { status: 404 });
    }

    if (new Date() > new Date(download.expiresAt)) {
      return NextResponse.json({ error: 'Download link has expired' }, { status: 410 });
    }

    if (download.downloadCount >= download.maxDownloads) {
      return NextResponse.json({ error: 'Download limit reached' }, { status: 429 });
    }

    const product = await prisma.product.findUnique({
      where: { id: download.productId },
    });

    if (!product?.filePath) {
      return NextResponse.json({ error: 'Product file not available' }, { status: 404 });
    }

    // Increment download count
    await prisma.download.update({
      where: { id: download.id },
      data: { downloadCount: { increment: 1 } },
    });

    // Get signed URL for download
    const contentType = 'application/octet-stream';
    const url = await getFileUrl(product.filePath, contentType, product.fileIsPublic);

    return NextResponse.redirect(url);
  } catch (error: any) {
    console.error('Download error:', error);
    return NextResponse.json({ error: 'Download failed' }, { status: 500 });
  }
}
