'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { ProductCard } from '@/components/product-card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, SlidersHorizontal, X, Package } from 'lucide-react';
import { getCategoryLabel, PRODUCT_CATEGORIES } from '@/lib/constants';
import { motion } from 'framer-motion';

interface Props {
  products: any[];
  categories: { category: string; _count: { id: number } }[];
  activeCategory: string | null;
  searchQuery: string;
  sortBy: string;
}

export function ProductsClient({ products, categories, activeCategory, searchQuery, sortBy }: Props) {
  const router = useRouter();
  const [search, setSearch] = useState(searchQuery ?? '');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (activeCategory) params.set('category', activeCategory);
    if (sortBy && sortBy !== 'newest') params.set('sort', sortBy);
    router.push(`/products?${params.toString()}`);
  };

  const handleCategoryClick = (cat: string | null) => {
    const params = new URLSearchParams();
    if (cat) params.set('category', cat);
    if (search) params.set('search', search);
    if (sortBy && sortBy !== 'newest') params.set('sort', sortBy);
    router.push(`/products?${params.toString()}`);
  };

  const handleSortChange = (sort: string) => {
    const params = new URLSearchParams();
    if (activeCategory) params.set('category', activeCategory);
    if (search) params.set('search', search);
    if (sort !== 'newest') params.set('sort', sort);
    router.push(`/products?${params.toString()}`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="max-w-[1200px] mx-auto px-4 py-8">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight mb-2">
              {activeCategory ? getCategoryLabel(activeCategory) : 'All Products'}
            </h1>
            <p className="text-muted-foreground mb-6">
              {(products?.length ?? 0)} product{(products?.length ?? 0) !== 1 ? 's' : ''} available
            </p>
          </motion.div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <form onSubmit={handleSearch} className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search products..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 pr-10"
              />
              {search && (
                <button type="button" onClick={() => { setSearch(''); router.push('/products'); }} className="absolute right-3 top-1/2 -translate-y-1/2">
                  <X className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                </button>
              )}
            </form>
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
              <select
                value={sortBy}
                onChange={(e) => handleSortChange(e.target.value)}
                className="bg-card border border-border rounded-lg px-3 py-2 text-sm"
              >
                <option value="newest">Newest</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
                <option value="name">Name</option>
              </select>
            </div>
          </div>

          {/* Category pills */}
          <div className="flex flex-wrap gap-2 mb-8">
            <Button
              size="sm"
              variant={!activeCategory ? 'default' : 'outline'}
              onClick={() => handleCategoryClick(null)}
            >
              All
            </Button>
            {PRODUCT_CATEGORIES.map((cat) => (
              <Button
                key={cat.value}
                size="sm"
                variant={activeCategory === cat.value ? 'default' : 'outline'}
                onClick={() => handleCategoryClick(cat.value)}
              >
                {cat.label}
              </Button>
            ))}
          </div>

          {/* Products grid */}
          {(products?.length ?? 0) > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {(products ?? []).map((product: any, i: number) => (
                <ProductCard key={product?.id ?? i} product={product} index={i} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <Package className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="font-display text-xl font-semibold mb-2">No products found</h3>
              <p className="text-muted-foreground mb-4">Try adjusting your search or filters</p>
              <Button variant="outline" onClick={() => router.push('/products')}>Clear Filters</Button>
            </div>
          )}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
