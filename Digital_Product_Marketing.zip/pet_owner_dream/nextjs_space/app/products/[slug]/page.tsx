import { prisma } from '@/lib/db';
import { notFound } from 'next/navigation';
import { ProductDetailClient } from './_components/product-detail-client';

export const dynamic = 'force-dynamic';

export default async function ProductDetailPage({
  params,
}: {
  params: { slug: string };
}) {
  const product = await prisma.product.findUnique({
    where: { slug: params?.slug ?? '' },
  });

  if (!product || !product.active) return notFound();

  const related = await prisma.product.findMany({
    where: {
      active: true,
      category: product.category,
      id: { not: product.id },
    },
    take: 4,
    select: { id: true, title: true, slug: true, price: true, compareAtPrice: true, imageUrl: true, category: true, featured: true, shortDescription: true },
  });

  return (
    <ProductDetailClient
      product={JSON.parse(JSON.stringify(product))}
      related={related ?? []}
    />
  );
}
