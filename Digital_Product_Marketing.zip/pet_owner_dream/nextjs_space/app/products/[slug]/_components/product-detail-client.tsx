'use client';

import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { ProductCard } from '@/components/product-card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/lib/cart-context';
import { formatPrice, getCategoryLabel } from '@/lib/constants';
import { ShoppingCart, Download, Star, ArrowLeft, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  product: any;
  related: any[];
}

export function ProductDetailClient({ product, related }: Props) {
  const { addItem, items } = useCart();
  const isInCart = (items ?? []).some((i: any) => i?.id === product?.id);
  const discount = product?.compareAtPrice
    ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
    : 0;

  const handleAddToCart = () => {
    if (!isInCart) {
      addItem({
        id: product?.id ?? '',
        title: product?.title ?? '',
        price: product?.price ?? 0,
        imageUrl: product?.imageUrl ?? null,
      });
      toast.success('Added to cart!');
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="max-w-[1200px] mx-auto px-4 py-8">
          <Link href="/products" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
            <ArrowLeft className="h-4 w-4" /> Back to Products
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Image */}
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
              <div className="relative aspect-video bg-muted rounded-lg overflow-hidden" style={{ boxShadow: 'var(--shadow-lg)' }}>
                {product?.imageUrl ? (
                  <Image
                    src={product.imageUrl}
                    alt={product?.title ?? 'Product'}
                    fill
                    className="object-cover"
                    priority
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Star className="h-20 w-20 text-muted-foreground/20" />
                  </div>
                )}
              </div>
            </motion.div>

            {/* Details */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
              <Badge variant="secondary" className="mb-3">{getCategoryLabel(product?.category ?? '')}</Badge>
              {product?.featured && (
                <Badge className="ml-2 bg-primary text-primary-foreground"><Star className="h-3 w-3 mr-1 fill-current" /> Featured</Badge>
              )}
              <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight mt-2 mb-4">
                {product?.title ?? 'Untitled Product'}
              </h1>

              <div className="flex items-baseline gap-3 mb-6">
                <span className="font-display text-3xl font-bold text-primary">{formatPrice(product?.price ?? 0)}</span>
                {product?.compareAtPrice && (
                  <>
                    <span className="text-lg text-muted-foreground line-through">{formatPrice(product.compareAtPrice)}</span>
                    <Badge variant="destructive">Save {discount}%</Badge>
                  </>
                )}
              </div>

              <div className="prose prose-sm max-w-none text-muted-foreground mb-8" dangerouslySetInnerHTML={{ __html: product?.description?.replace?.(/\n/g, '<br/>') ?? '' }} />

              <div className="space-y-3 mb-8">
                <div className="flex items-center gap-2 text-sm"><CheckCircle className="h-4 w-4 text-green-500" /> Instant digital download</div>
                <div className="flex items-center gap-2 text-sm"><Download className="h-4 w-4 text-green-500" /> Lifetime access to your files</div>
                <div className="flex items-center gap-2 text-sm"><Star className="h-4 w-4 text-green-500" /> Money-back guarantee</div>
              </div>

              <div className="flex gap-3">
                <Button
                  size="lg"
                  className="gap-2 flex-1"
                  onClick={handleAddToCart}
                  disabled={isInCart}
                >
                  <ShoppingCart className="h-5 w-5" />
                  {isInCart ? 'Already in Cart' : 'Add to Cart'}
                </Button>
                {isInCart && (
                  <Link href="/cart">
                    <Button size="lg" variant="outline">View Cart</Button>
                  </Link>
                )}
              </div>
            </motion.div>
          </div>

          {/* Related */}
          {(related?.length ?? 0) > 0 && (
            <div className="mt-16">
              <h2 className="font-display text-2xl font-bold tracking-tight mb-6">Related Products</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {(related ?? []).map((p: any, i: number) => (
                  <ProductCard key={p?.id ?? i} product={p} index={i} />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
