import { prisma } from '@/lib/db';
import { ProductsClient } from './_components/products-client';

export const dynamic = 'force-dynamic';

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: { category?: string; search?: string; sort?: string };
}) {
  const where: any = { active: true };
  if (searchParams?.category) where.category = searchParams.category;
  if (searchParams?.search) {
    where.OR = [
      { title: { contains: searchParams.search, mode: 'insensitive' } },
      { description: { contains: searchParams.search, mode: 'insensitive' } },
    ];
  }

  let orderBy: any = { createdAt: 'desc' };
  if (searchParams?.sort === 'price_asc') orderBy = { price: 'asc' };
  if (searchParams?.sort === 'price_desc') orderBy = { price: 'desc' };
  if (searchParams?.sort === 'name') orderBy = { title: 'asc' };

  const [products, categories] = await Promise.all([
    prisma.product.findMany({
      where,
      orderBy,
      select: { id: true, title: true, slug: true, price: true, compareAtPrice: true, imageUrl: true, category: true, featured: true, shortDescription: true },
    }),
    prisma.product.groupBy({
      by: ['category'],
      where: { active: true },
      _count: { id: true },
    }),
  ]);

  return (
    <ProductsClient
      products={products ?? []}
      categories={categories ?? []}
      activeCategory={searchParams?.category ?? null}
      searchQuery={searchParams?.search ?? ''}
      sortBy={searchParams?.sort ?? 'newest'}
    />
  );
}
