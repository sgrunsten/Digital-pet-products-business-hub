'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { DollarSign, ShoppingBag, Package, Users, Mail, TrendingUp } from 'lucide-react';
import { formatPrice, getCategoryLabel } from '@/lib/constants';
import dynamic from 'next/dynamic';

const RevenueChart = dynamic(() => import('./_components/revenue-chart'), { ssr: false, loading: () => <div className="h-[300px] animate-pulse bg-muted rounded-lg" /> });

interface Analytics {
  totalOrders: number;
  totalRevenue: number;
  totalProducts: number;
  totalCustomers: number;
  subscribers: number;
  recentOrders: any[];
  topProducts: any[];
  categoryStats: any[];
  revenueChart: { month: string; revenue: number }[];
}

export default function AdminDashboard() {
  const [data, setData] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/analytics')
      .then((r) => r.json())
      .then((d) => setData(d))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 bg-muted animate-pulse rounded w-64" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1,2,3,4].map((i) => <div key={i} className="h-28 bg-muted animate-pulse rounded-lg" />)}
        </div>
      </div>
    );
  }

  const stats = [
    { label: 'Total Revenue', value: formatPrice(data?.totalRevenue ?? 0), icon: DollarSign, color: 'text-green-600 bg-green-100' },
    { label: 'Orders', value: String(data?.totalOrders ?? 0), icon: ShoppingBag, color: 'text-blue-600 bg-blue-100' },
    { label: 'Products', value: String(data?.totalProducts ?? 0), icon: Package, color: 'text-purple-600 bg-purple-100' },
    { label: 'Customers', value: String(data?.totalCustomers ?? 0), icon: Users, color: 'text-amber-600 bg-amber-100' },
  ];

  return (
    <div className="space-y-6 max-w-[1200px]">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your store performance</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card rounded-lg p-4" style={{ boxShadow: 'var(--shadow-sm)' }}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${stat.color}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="font-display font-bold text-xl">{stat.value}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-card rounded-lg p-6" style={{ boxShadow: 'var(--shadow-sm)' }}>
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h2 className="font-display font-semibold">Revenue Trend</h2>
          </div>
          <div className="h-[300px]">
            <RevenueChart data={data?.revenueChart ?? []} />
          </div>
        </div>

        {/* Top Products */}
        <div className="bg-card rounded-lg p-6" style={{ boxShadow: 'var(--shadow-sm)' }}>
          <h2 className="font-display font-semibold mb-4">Top Products</h2>
          <div className="space-y-3">
            {(data?.topProducts ?? []).map((p: any, i: number) => (
              <div key={p?.id ?? i} className="flex items-center justify-between p-2 bg-muted/30 rounded-lg">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{p?.title ?? 'Product'}</p>
                  <p className="text-xs text-muted-foreground">{p?.downloadCount ?? 0} sales</p>
                </div>
                <span className="text-sm font-semibold">{formatPrice(p?.price ?? 0)}</span>
              </div>
            ))}
            {(data?.topProducts?.length ?? 0) === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">No products yet</p>
            )}
          </div>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-card rounded-lg p-6" style={{ boxShadow: 'var(--shadow-sm)' }}>
        <h2 className="font-display font-semibold mb-4">Recent Orders</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-muted-foreground border-b border-border">
                <th className="py-2 px-3">Order</th>
                <th className="py-2 px-3">Customer</th>
                <th className="py-2 px-3">Items</th>
                <th className="py-2 px-3">Total</th>
                <th className="py-2 px-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {(data?.recentOrders ?? []).map((order: any, i: number) => (
                <tr key={order?.id ?? i} className="border-b border-border/50 hover:bg-muted/20">
                  <td className="py-2.5 px-3 font-mono text-xs">{order?.orderNumber ?? ''}</td>
                  <td className="py-2.5 px-3">{order?.customerEmail ?? ''}</td>
                  <td className="py-2.5 px-3">{order?.items?.length ?? 0}</td>
                  <td className="py-2.5 px-3 font-medium">{formatPrice(order?.total ?? 0)}</td>
                  <td className="py-2.5 px-3">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                      order?.status === 'completed' ? 'bg-green-100 text-green-700' :
                      order?.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {order?.status ?? 'unknown'}
                    </span>
                  </td>
                </tr>
              ))}
              {(data?.recentOrders?.length ?? 0) === 0 && (
                <tr><td colSpan={5} className="py-8 text-center text-muted-foreground">No orders yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Subscribers count */}
      <div className="bg-card rounded-lg p-4 flex items-center gap-3" style={{ boxShadow: 'var(--shadow-sm)' }}>
        <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-primary/10">
          <Mail className="h-5 w-5 text-primary" />
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Newsletter Subscribers</p>
          <p className="font-display font-bold text-lg">{data?.subscribers ?? 0}</p>
        </div>
      </div>
    </div>
  );
}
