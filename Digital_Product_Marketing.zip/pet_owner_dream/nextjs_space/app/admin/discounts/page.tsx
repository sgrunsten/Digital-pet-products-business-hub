'use client';

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tag, Plus, X } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdminDiscountsPage() {
  const [codes, setCodes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ code: '', type: 'percentage', value: '', minOrderAmount: '', maxUses: '', expiresAt: '' });
  const [saving, setSaving] = useState(false);

  const fetchCodes = () => {
    fetch('/api/admin/discount-codes')
      .then((r) => r.json())
      .then((d) => setCodes(d ?? []))
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchCodes(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form?.code?.trim() || !form?.value) { toast.error('Code and value required'); return; }
    setSaving(true);
    try {
      const res = await fetch('/api/admin/discount-codes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        toast.success('Discount code created!');
        setShowForm(false);
        setForm({ code: '', type: 'percentage', value: '', minOrderAmount: '', maxUses: '', expiresAt: '' });
        fetchCodes();
      } else {
        const data = await res.json();
        toast.error(data?.error ?? 'Failed');
      }
    } catch {
      toast.error('Failed to create discount');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-[900px]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Discount Codes</h1>
          <p className="text-muted-foreground">{codes?.length ?? 0} discount codes</p>
        </div>
        <Button className="gap-2" onClick={() => setShowForm(!showForm)}>
          {showForm ? <><X className="h-4 w-4" /> Cancel</> : <><Plus className="h-4 w-4" /> New Code</>}
        </Button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleCreate}
            className="bg-card rounded-lg p-6 space-y-4 overflow-hidden"
            style={{ boxShadow: 'var(--shadow-md)' }}
          >
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Code *</label>
                <Input value={form?.code ?? ''} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="PETLOVE20" required />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Type</label>
                <select value={form?.type ?? 'percentage'} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
                  <option value="percentage">Percentage (%)</option>
                  <option value="fixed">Fixed Amount ($)</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Value *</label>
                <Input type="number" step="0.01" value={form?.value ?? ''} onChange={(e) => setForm({ ...form, value: e.target.value })} placeholder="20" required />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Min Order ($)</label>
                <Input type="number" step="0.01" value={form?.minOrderAmount ?? ''} onChange={(e) => setForm({ ...form, minOrderAmount: e.target.value })} placeholder="0" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Max Uses</label>
                <Input type="number" value={form?.maxUses ?? ''} onChange={(e) => setForm({ ...form, maxUses: e.target.value })} placeholder="Unlimited" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Expires At</label>
              <Input type="date" value={form?.expiresAt ?? ''} onChange={(e) => setForm({ ...form, expiresAt: e.target.value })} />
            </div>
            <Button type="submit" loading={saving}>Create Discount Code</Button>
          </motion.form>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="space-y-3">{[1,2].map((i) => <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />)}</div>
      ) : (codes?.length ?? 0) === 0 ? (
        <div className="text-center py-20">
          <Tag className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="font-display text-xl font-semibold">No discount codes yet</h3>
        </div>
      ) : (
        <div className="space-y-3">
          {(codes ?? []).map((code: any, i: number) => (
            <motion.div
              key={code?.id ?? i}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              className={`bg-card rounded-lg p-4 flex items-center justify-between ${!code?.active ? 'opacity-60' : ''}`}
              style={{ boxShadow: 'var(--shadow-sm)' }}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Tag className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-mono font-bold">{code?.code ?? ''}</p>
                  <p className="text-xs text-muted-foreground">
                    {code?.type === 'percentage' ? `${code?.value ?? 0}% off` : `$${code?.value ?? 0} off`}
                    {code?.minOrderAmount ? ` • Min $${code.minOrderAmount}` : ''}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm">{code?.usedCount ?? 0}{code?.maxUses ? ` / ${code.maxUses}` : ''} uses</p>
                <p className="text-xs text-muted-foreground">
                  {code?.expiresAt ? `Expires ${new Date(code.expiresAt).toLocaleDateString('en-US', { timeZone: 'UTC' })}` : 'No expiry'}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
