'use client';

import { useEffect, useState } from 'react';
import { formatPrice } from '@/lib/constants';
import { Users } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AdminCustomersPage() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/orders')
      .then((r) => r.json())
      .then((orders: any[]) => {
        const customerMap: Record<string, { email: string; name: string | null; orders: number; totalSpent: number; lastOrder: string }> = {};
        (orders ?? []).forEach((o: any) => {
          const email = o?.customerEmail ?? '';
          if (!customerMap[email]) {
            customerMap[email] = { email, name: o?.customerName ?? null, orders: 0, totalSpent: 0, lastOrder: '' };
          }
          customerMap[email].orders += 1;
          customerMap[email].totalSpent += (o?.total ?? 0);
          if (!customerMap[email].lastOrder || new Date(o?.createdAt) > new Date(customerMap[email].lastOrder)) {
            customerMap[email].lastOrder = o?.createdAt ?? '';
          }
          if (o?.customerName && !customerMap[email].name) {
            customerMap[email].name = o.customerName;
          }
        });
        setCustomers(Object.values(customerMap ?? {}).sort((a, b) => (b?.totalSpent ?? 0) - (a?.totalSpent ?? 0)));
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6 max-w-[1200px]">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">Customers</h1>
        <p className="text-muted-foreground">{customers?.length ?? 0} unique customers</p>
      </div>

      {loading ? (
        <div className="space-y-3">{[1,2,3].map((i) => <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />)}</div>
      ) : (customers?.length ?? 0) === 0 ? (
        <div className="text-center py-20">
          <Users className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="font-display text-xl font-semibold">No customers yet</h3>
        </div>
      ) : (
        <div className="bg-card rounded-lg overflow-hidden" style={{ boxShadow: 'var(--shadow-sm)' }}>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-muted-foreground bg-muted/30">
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Orders</th>
                <th className="py-3 px-4">Total Spent</th>
                <th className="py-3 px-4">Last Order</th>
              </tr>
            </thead>
            <tbody>
              {(customers ?? []).map((c: any, i: number) => (
                <motion.tr
                  key={c?.email ?? i}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.03 }}
                  className="border-t border-border/50 hover:bg-muted/20"
                >
                  <td className="py-3 px-4">
                    <div className="font-medium">{c?.name ?? 'Guest'}</div>
                    <div className="text-xs text-muted-foreground">{c?.email ?? ''}</div>
                  </td>
                  <td className="py-3 px-4">{c?.orders ?? 0}</td>
                  <td className="py-3 px-4 font-medium">{formatPrice(c?.totalSpent ?? 0)}</td>
                  <td className="py-3 px-4 text-xs text-muted-foreground">
                    {c?.lastOrder ? new Date(c.lastOrder).toLocaleDateString('en-US', { timeZone: 'UTC' }) : ''}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
