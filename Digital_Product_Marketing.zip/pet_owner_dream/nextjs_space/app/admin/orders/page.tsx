'use client';

import { useEffect, useState } from 'react';
import { formatPrice } from '@/lib/constants';
import { ShoppingBag, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { motion } from 'framer-motion';

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('/api/orders')
      .then((r) => r.json())
      .then((d) => setOrders(d ?? []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const filtered = (orders ?? []).filter((o: any) =>
    !search || (o?.orderNumber ?? '').toLowerCase().includes(search.toLowerCase()) ||
    (o?.customerEmail ?? '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 max-w-[1200px]">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">Orders</h1>
        <p className="text-muted-foreground">{orders?.length ?? 0} total orders</p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search by order number or email..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
      </div>

      {loading ? (
        <div className="space-y-3">{[1,2,3].map((i) => <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />)}</div>
      ) : (filtered?.length ?? 0) === 0 ? (
        <div className="text-center py-20">
          <ShoppingBag className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="font-display text-xl font-semibold">No orders found</h3>
        </div>
      ) : (
        <div className="bg-card rounded-lg overflow-hidden" style={{ boxShadow: 'var(--shadow-sm)' }}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-muted-foreground bg-muted/30">
                  <th className="py-3 px-4">Order</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Products</th>
                  <th className="py-3 px-4">Discount</th>
                  <th className="py-3 px-4">Total</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Date</th>
                </tr>
              </thead>
              <tbody>
                {(filtered ?? []).map((order: any, i: number) => (
                  <motion.tr
                    key={order?.id ?? i}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.02 }}
                    className="border-t border-border/50 hover:bg-muted/20"
                  >
                    <td className="py-3 px-4 font-mono text-xs">{order?.orderNumber ?? ''}</td>
                    <td className="py-3 px-4">
                      <div>{order?.customerName ?? ''}</div>
                      <div className="text-xs text-muted-foreground">{order?.customerEmail ?? ''}</div>
                    </td>
                    <td className="py-3 px-4">
                      {(order?.items ?? []).map((item: any, j: number) => (
                        <div key={j} className="text-xs">{item?.product?.title ?? 'Product'}</div>
                      ))}
                    </td>
                    <td className="py-3 px-4">
                      {(order?.discount ?? 0) > 0 ? (
                        <span className="text-green-600">-{formatPrice(order.discount)}</span>
                      ) : '—'}
                    </td>
                    <td className="py-3 px-4 font-medium">{formatPrice(order?.total ?? 0)}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        order?.status === 'completed' ? 'bg-green-100 text-green-700' :
                        order?.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>{order?.status ?? 'unknown'}</span>
                    </td>
                    <td className="py-3 px-4 text-xs text-muted-foreground">
                      {order?.createdAt ? new Date(order.createdAt).toLocaleDateString('en-US', { timeZone: 'UTC' }) : ''}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
