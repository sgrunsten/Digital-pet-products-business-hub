'use client';

import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';

export default function RevenueChart({ data }: { data: { month: string; revenue: number }[] }) {
  if ((data?.length ?? 0) === 0) {
    return <div className="h-full flex items-center justify-center text-muted-foreground text-sm">No revenue data yet</div>;
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data ?? []} margin={{ top: 5, right: 10, left: 10, bottom: 20 }}>
        <defs>
          <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
          </linearGradient>
        </defs>
        <XAxis
          dataKey="month"
          tickLine={false}
          tick={{ fontSize: 10 }}
          interval="preserveStartEnd"
          label={{ value: 'Month', position: 'insideBottom', offset: -15, style: { textAnchor: 'middle', fontSize: 11 } }}
        />
        <YAxis
          tickLine={false}
          tick={{ fontSize: 10 }}
          tickFormatter={(v: number) => `$${(v ?? 0) >= 1000 ? `${((v ?? 0) / 1000).toFixed(1)}k` : v}`}
          label={{ value: 'Revenue', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fontSize: 11 } }}
        />
        <Tooltip
          contentStyle={{ fontSize: 11, borderRadius: 8 }}
          formatter={(value: any) => [`$${(value ?? 0).toFixed(2)}`, 'Revenue']}
        />
        <Area
          type="monotone"
          dataKey="revenue"
          stroke="#f59e0b"
          strokeWidth={2}
          fill="url(#revenueGradient)"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
