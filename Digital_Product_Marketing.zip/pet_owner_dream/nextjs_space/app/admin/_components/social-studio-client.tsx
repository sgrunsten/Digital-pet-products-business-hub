'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { SOCIAL_PLATFORMS, getPlatformLabel, buildShareUrl } from '@/lib/constants';
import {
  Megaphone,
  Sparkles,
  Copy,
  Download,
  Calendar as CalendarIcon,
  Share2,
  Trash2,
  Loader2,
  ExternalLink,
  ImageIcon,
  Info,
  CheckCircle2,
} from 'lucide-react';

type Product = {
  id: string;
  title: string;
  slug: string;
  category: string;
  imageUrl?: string | null;
};

type GeneratedPost = {
  platform: string;
  content: string;
  hashtags: string;
  charLimit: number;
};

type SavedPost = {
  id: string;
  productId: string | null;
  productTitle: string | null;
  platform: string;
  content: string;
  hashtags: string;
  imageUrl: string | null;
  scheduledFor: string | null;
  status: string;
};

const MANUAL_PLATFORMS = ['instagram', 'tiktok'];

function platformColor(value: string): string {
  return SOCIAL_PLATFORMS.find((p) => p.value === value)?.color ?? '#6b7280';
}

function formatDateLabel(iso: string | null): string {
  if (!iso) return 'Not scheduled';
  const d = new Date(iso);
  return d.toLocaleString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    timeZone: 'UTC',
  });
}

export function SocialStudioClient() {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<string>('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([
    'facebook',
    'instagram',
  ]);
  const [tone, setTone] = useState('');
  const [withImage, setWithImage] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [results, setResults] = useState<GeneratedPost[]>([]);
  const [genImageUrl, setGenImageUrl] = useState<string | null>(null);
  const [genProductTitle, setGenProductTitle] = useState<string>('');

  const [savedPosts, setSavedPosts] = useState<SavedPost[]>([]);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [origin, setOrigin] = useState('https://petownersdream.com');

  useEffect(() => {
    if (typeof window !== 'undefined') setOrigin(window.location.origin);
    fetch('/api/products?active=all')
      .then((r) => r.json())
      .then((d) => setProducts(Array.isArray(d) ? d : []))
      .catch(() => setProducts([]));
    fetchSavedPosts();
  }, []);

  const fetchSavedPosts = () => {
    setLoadingPosts(true);
    fetch('/api/social/posts')
      .then((r) => r.json())
      .then((d) => setSavedPosts(d?.posts ?? []))
      .catch(() => setSavedPosts([]))
      .finally(() => setLoadingPosts(false));
  };

  const currentProduct = useMemo(
    () => products.find((p) => p.id === selectedProduct),
    [products, selectedProduct]
  );

  const productUrl = currentProduct
    ? `${origin}/products/${currentProduct.slug}`
    : origin;

  const togglePlatform = (value: string) => {
    setSelectedPlatforms((prev) =>
      prev.includes(value) ? prev.filter((p) => p !== value) : [...prev, value]
    );
  };

  const handleGenerate = async () => {
    if (!selectedProduct) {
      toast.error('Please pick a product first.');
      return;
    }
    if (selectedPlatforms.length === 0) {
      toast.error('Please pick at least one platform.');
      return;
    }
    setGenerating(true);
    setResults([]);
    setGenImageUrl(null);
    try {
      const res = await fetch('/api/social/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: selectedProduct,
          platforms: selectedPlatforms,
          tone,
          generateImage: withImage,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data?.error ?? 'Failed to generate content.');
        return;
      }
      setResults(data.posts ?? []);
      setGenImageUrl(data.imageUrl ?? null);
      setGenProductTitle(data.productTitle ?? '');
      toast.success('Content generated! Review and tweak below.');
    } catch {
      toast.error('Something went wrong while generating.');
    } finally {
      setGenerating(false);
    }
  };

  const updateResult = (platform: string, field: 'content' | 'hashtags', value: string) => {
    setResults((prev) =>
      prev.map((r) => (r.platform === platform ? { ...r, [field]: value } : r))
    );
  };

  const copyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied!`);
  };

  const fullCaption = (post: GeneratedPost) =>
    `${post.content}\n\n${post.hashtags}`.trim();

  const handleShare = (post: GeneratedPost) => {
    const shareUrl = buildShareUrl(post.platform, {
      url: productUrl,
      text: fullCaption(post),
      imageUrl: genImageUrl ?? currentProduct?.imageUrl ?? '',
      title: genProductTitle,
    });
    if (shareUrl) {
      window.open(shareUrl, '_blank', 'noopener,noreferrer');
    } else {
      copyText(fullCaption(post), 'Caption');
      toast.info(`${getPlatformLabel(post.platform)} needs manual posting — caption copied. Open the app and paste it.`);
    }
  };

  const handleSaveToSchedule = async (post: GeneratedPost, scheduledFor: string | null) => {
    try {
      const res = await fetch('/api/social/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: selectedProduct,
          productTitle: genProductTitle,
          platform: post.platform,
          content: post.content,
          hashtags: post.hashtags,
          imageUrl: genImageUrl,
          scheduledFor,
          status: scheduledFor ? 'scheduled' : 'draft',
        }),
      });
      if (!res.ok) {
        toast.error('Failed to save.');
        return;
      }
      toast.success(scheduledFor ? 'Post scheduled!' : 'Saved as draft!');
      fetchSavedPosts();
    } catch {
      toast.error('Failed to save.');
    }
  };

  const exportPackage = (post: GeneratedPost) => {
    const platform = getPlatformLabel(post.platform);
    const manualNote = MANUAL_PLATFORMS.includes(post.platform)
      ? `\n\nHOW TO POST: ${platform} requires posting from the app. Copy the caption above, open ${platform}, upload your image, and paste.`
      : `\n\nHOW TO POST: Use the one-click share button in Social Studio, or paste this into ${platform} directly.`;
    const content = `PLATFORM: ${platform}\nPRODUCT: ${genProductTitle}\nPRODUCT LINK: ${productUrl}\n${genImageUrl ? `IMAGE: ${genImageUrl}\n` : ''}\n--- CAPTION ---\n${post.content}\n\n--- HASHTAGS ---\n${post.hashtags}${manualNote}\n\nTip: You can also schedule this free using Buffer (buffer.com) or Later (later.com).`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${post.platform}-post.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Ready-to-post package downloaded!');
  };

  const deleteSaved = async (id: string) => {
    if (!confirm('Delete this post?')) return;
    try {
      await fetch(`/api/social/posts/${id}`, { method: 'DELETE' });
      toast.success('Post deleted.');
      fetchSavedPosts();
    } catch {
      toast.error('Failed to delete.');
    }
  };

  const markPosted = async (id: string) => {
    try {
      await fetch(`/api/social/posts/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'posted' }),
      });
      toast.success('Marked as posted!');
      fetchSavedPosts();
    } catch {
      toast.error('Failed to update.');
    }
  };

  const groupedByDate = useMemo(() => {
    const groups: Record<string, SavedPost[]> = {};
    for (const post of savedPosts) {
      const key = post.scheduledFor
        ? new Date(post.scheduledFor).toLocaleDateString('en-US', {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            timeZone: 'UTC',
          })
        : 'Drafts (no date)';
      if (!groups[key]) groups[key] = [];
      groups[key].push(post);
    }
    return groups;
  }, [savedPosts]);

  return (
    <div className="space-y-6 max-w-[1200px]">
      <div className="flex items-center gap-3">
        <div className="h-11 w-11 rounded-xl bg-primary/10 flex items-center justify-center">
          <Megaphone className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Social Studio</h1>
          <p className="text-muted-foreground">
            Turn any product into ready-to-post social content in seconds.
          </p>
        </div>
      </div>

      <Tabs defaultValue="create" className="w-full">
        <TabsList>
          <TabsTrigger value="create" className="gap-2">
            <Sparkles className="h-4 w-4" /> Create Content
          </TabsTrigger>
          <TabsTrigger value="calendar" className="gap-2">
            <CalendarIcon className="h-4 w-4" /> Posting Calendar
            {savedPosts.length > 0 && (
              <Badge variant="secondary" className="ml-1">{savedPosts.length}</Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* CREATE TAB */}
        <TabsContent value="create" className="space-y-6 pt-4">
          <div className="bg-card rounded-xl p-6 space-y-5" style={{ boxShadow: 'var(--shadow-sm)' }}>
            <div className="grid gap-5 md:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium">1. Pick a product</label>
                <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a product to promote" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-2 space-y-2">
                <label className="text-sm font-medium">
                  3. Tone <span className="text-muted-foreground font-normal">(optional)</span>
                </label>
                <Input
                  placeholder="e.g. playful, professional, excited"
                  value={tone}
                  onChange={(e) => setTone(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">2. Pick platforms</label>
              <div className="flex flex-wrap gap-2">
                {SOCIAL_PLATFORMS.map((p) => {
                  const active = selectedPlatforms.includes(p.value);
                  return (
                    <button
                      key={p.value}
                      type="button"
                      onClick={() => togglePlatform(p.value)}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all ${
                        active
                          ? 'text-white border-transparent'
                          : 'bg-background text-foreground border-border hover:border-primary/50'
                      }`}
                      style={active ? { backgroundColor: p.color } : undefined}
                    >
                      {p.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-between rounded-lg bg-muted/50 p-3">
              <div className="flex items-center gap-2">
                <ImageIcon className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Also generate a promo image</span>
              </div>
              <Switch checked={withImage} onCheckedChange={setWithImage} />
            </div>

            <Button
              onClick={handleGenerate}
              disabled={generating}
              size="lg"
              className="gap-2 w-full sm:w-auto"
            >
              {generating ? (
                <><Loader2 className="h-4 w-4 animate-spin" /> Generating…</>
              ) : (
                <><Sparkles className="h-4 w-4" /> Generate Content</>
              )}
            </Button>
          </div>

          {genImageUrl && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-xl p-4 flex items-center gap-4"
              style={{ boxShadow: 'var(--shadow-sm)' }}
            >
              <div className="relative w-24 h-24 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={genImageUrl} alt="Generated promo" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1">
                <p className="font-medium">Your promo image is ready</p>
                <p className="text-sm text-muted-foreground">Use it on any platform below.</p>
                <Button variant="outline" size="sm" className="mt-2 gap-1.5" onClick={() => copyText(genImageUrl, 'Image link')}>
                  <Copy className="h-3.5 w-3.5" /> Copy image link
                </Button>
              </div>
            </motion.div>
          )}

          <div className="grid gap-4 md:grid-cols-2">
            {results.map((post, i) => {
              const isManual = MANUAL_PLATFORMS.includes(post.platform);
              const overLimit = post.content.length > post.charLimit;
              return (
                <motion.div
                  key={post.platform}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-card rounded-xl p-5 space-y-3"
                  style={{ boxShadow: 'var(--shadow-sm)' }}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className="px-2.5 py-1 rounded-full text-xs font-semibold text-white"
                      style={{ backgroundColor: platformColor(post.platform) }}
                    >
                      {getPlatformLabel(post.platform)}
                    </span>
                    <span className={`text-xs ${overLimit ? 'text-destructive font-semibold' : 'text-muted-foreground'}`}>
                      {post.content.length}/{post.charLimit}
                    </span>
                  </div>

                  <Textarea
                    value={post.content}
                    onChange={(e) => updateResult(post.platform, 'content', e.target.value)}
                    rows={5}
                    className="resize-none"
                  />
                  <Input
                    value={post.hashtags}
                    onChange={(e) => updateResult(post.platform, 'hashtags', e.target.value)}
                    placeholder="#hashtags"
                  />

                  {isManual && (
                    <div className="flex items-start gap-2 text-xs text-muted-foreground bg-muted/50 rounded-md p-2">
                      <Info className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
                      <span>{getPlatformLabel(post.platform)} posts manually. Copy the caption, then post from the app.</span>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2 pt-1">
                    <Button variant="outline" size="sm" className="gap-1.5" onClick={() => copyText(fullCaption(post), 'Caption')}>
                      <Copy className="h-3.5 w-3.5" /> Copy
                    </Button>
                    <Button variant="outline" size="sm" className="gap-1.5" onClick={() => handleShare(post)}>
                      {isManual ? <Share2 className="h-3.5 w-3.5" /> : <ExternalLink className="h-3.5 w-3.5" />}
                      {isManual ? 'Copy to post' : 'Share now'}
                    </Button>
                    <Button variant="outline" size="sm" className="gap-1.5" onClick={() => exportPackage(post)}>
                      <Download className="h-3.5 w-3.5" /> Export
                    </Button>
                    <ScheduleButton onSave={(dt) => handleSaveToSchedule(post, dt)} />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </TabsContent>

        {/* CALENDAR TAB */}
        <TabsContent value="calendar" className="space-y-5 pt-4">
          {loadingPosts ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />)}
            </div>
          ) : savedPosts.length === 0 ? (
            <div className="text-center py-20">
              <CalendarIcon className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="font-display text-xl font-semibold mb-2">No scheduled posts yet</h3>
              <p className="text-muted-foreground">Generate content and save it to your calendar.</p>
            </div>
          ) : (
            Object.entries(groupedByDate).map(([date, posts]) => (
              <div key={date} className="space-y-3">
                <h3 className="font-display font-semibold text-sm text-muted-foreground uppercase tracking-wide">{date}</h3>
                {posts.map((post) => (
                  <div
                    key={post.id}
                    className="bg-card rounded-lg p-4 space-y-2"
                    style={{ boxShadow: 'var(--shadow-sm)' }}
                  >
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className="px-2 py-0.5 rounded-full text-xs font-semibold text-white"
                        style={{ backgroundColor: platformColor(post.platform) }}
                      >
                        {getPlatformLabel(post.platform)}
                      </span>
                      <Badge variant={post.status === 'posted' ? 'default' : 'secondary'}>
                        {post.status}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{formatDateLabel(post.scheduledFor)}</span>
                      {post.productTitle && (
                        <span className="text-xs text-muted-foreground">• {post.productTitle}</span>
                      )}
                    </div>
                    <p className="text-sm whitespace-pre-wrap line-clamp-3">{post.content}</p>
                    {post.hashtags && <p className="text-xs text-primary">{post.hashtags}</p>}
                    <div className="flex flex-wrap gap-2 pt-1">
                      <Button variant="outline" size="sm" className="gap-1.5" onClick={() => copyText(`${post.content}\n\n${post.hashtags}`.trim(), 'Caption')}>
                        <Copy className="h-3.5 w-3.5" /> Copy
                      </Button>
                      {post.status !== 'posted' && (
                        <Button variant="outline" size="sm" className="gap-1.5" onClick={() => markPosted(post.id)}>
                          <CheckCircle2 className="h-3.5 w-3.5" /> Mark posted
                        </Button>
                      )}
                      <Button variant="ghost" size="sm" className="gap-1.5 text-destructive" onClick={() => deleteSaved(post.id)}>
                        <Trash2 className="h-3.5 w-3.5" /> Delete
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ScheduleButton({ onSave }: { onSave: (dt: string | null) => void }) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState('');

  return (
    <div className="relative inline-block">
      <Button variant="default" size="sm" className="gap-1.5" onClick={() => setOpen((o) => !o)}>
        <CalendarIcon className="h-3.5 w-3.5" /> Schedule
      </Button>
      {open && (
        <div className="absolute z-20 mt-2 right-0 bg-popover border rounded-lg p-3 shadow-lg w-64 space-y-2">
          <label className="text-xs font-medium">Pick date &amp; time</label>
          <Input
            type="datetime-local"
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
          <div className="flex gap-2">
            <Button
              size="sm"
              className="flex-1"
              onClick={() => {
                onSave(value ? new Date(value).toISOString() : null);
                setOpen(false);
              }}
            >
              Save
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                onSave(null);
                setOpen(false);
              }}
            >
              Draft
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
