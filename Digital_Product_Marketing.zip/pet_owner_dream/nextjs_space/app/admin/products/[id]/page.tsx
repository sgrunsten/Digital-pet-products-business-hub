'use client';

import { useEffect, useState } from 'react';
import { ProductForm } from '../_components/product-form';

export default function EditProductPage({ params }: { params: { id: string } }) {
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/products/${params?.id ?? ''}`)
      .then((r) => r.json())
      .then((d) => setProduct(d))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [params?.id]);

  if (loading) return <div className="animate-pulse h-96 bg-muted rounded-lg" />;

  return (
    <div className="max-w-[800px]">
      <h1 className="font-display text-2xl font-bold tracking-tight mb-6">Edit Product</h1>
      <ProductForm product={product} />
    </div>
  );
}
