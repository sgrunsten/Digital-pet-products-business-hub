'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PRODUCT_CATEGORIES, PRODUCT_TYPES } from '@/lib/constants';
import { Save, Upload, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import Link from 'next/link';

interface Props {
  product?: any;
}

export function ProductForm({ product }: Props) {
  const router = useRouter();
  const isEdit = !!product?.id;
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  const [form, setForm] = useState({
    title: product?.title ?? '',
    description: product?.description ?? '',
    shortDescription: product?.shortDescription ?? '',
    price: product?.price?.toString() ?? '',
    compareAtPrice: product?.compareAtPrice?.toString() ?? '',
    category: product?.category ?? 'ebooks',
    productType: product?.productType ?? 'ebook',
    imageUrl: product?.imageUrl ?? '',
    featured: product?.featured ?? false,
    active: product?.active ?? true,
    filePath: product?.filePath ?? '',
    fileIsPublic: product?.fileIsPublic ?? false,
    fileName: product?.fileName ?? '',
    fileSize: product?.fileSize?.toString() ?? '',
  });

  const handleChange = (field: string, value: any) => {
    setForm((prev) => ({ ...(prev ?? {}), [field]: value }));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target?.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const res = await fetch('/api/upload/presigned', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName: file.name, contentType: file.type, isPublic: false }),
      });
      const { uploadUrl, cloud_storage_path } = await res.json();

      await fetch(uploadUrl, {
        method: 'PUT',
        headers: { 'Content-Type': file.type },
        body: file,
      });

      handleChange('filePath', cloud_storage_path);
      handleChange('fileName', file.name);
      handleChange('fileSize', file.size.toString());
      toast.success('File uploaded successfully');
    } catch {
      toast.error('File upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target?.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const res = await fetch('/api/upload/presigned', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName: file.name, contentType: file.type, isPublic: true }),
      });
      const data = await res.json();

      await fetch(data?.uploadUrl, {
        method: 'PUT',
        headers: { 'Content-Type': file.type },
        body: file,
      });

      // Construct public URL
      const bucketName = process.env.NEXT_PUBLIC_AWS_BUCKET_NAME ?? '';
      const region = process.env.NEXT_PUBLIC_AWS_REGION ?? 'us-east-1';
      if (bucketName) {
        const publicUrl = `https://${bucketName}.s3.${region}.amazonaws.com/${data?.cloud_storage_path}`;
        handleChange('imageUrl', publicUrl);
      } else {
        handleChange('imageUrl', data?.cloud_storage_path ?? '');
      }
      toast.success('Image uploaded');
    } catch {
      toast.error('Image upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form?.title?.trim()) { toast.error('Title is required'); return; }
    if (!form?.price) { toast.error('Price is required'); return; }
    setLoading(true);
    try {
      const url = isEdit ? `/api/products/${product?.id}` : '/api/products';
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        toast.success(isEdit ? 'Product updated!' : 'Product created!');
        router.push('/admin/products');
      } else {
        const data = await res.json();
        toast.error(data?.error ?? 'Failed');
      }
    } catch {
      toast.error('Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Link href="/admin/products" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to Products
      </Link>

      <div className="bg-card rounded-lg p-6 space-y-4" style={{ boxShadow: 'var(--shadow-md)' }}>
        <h2 className="font-display font-semibold">Basic Information</h2>
        <div>
          <label className="text-sm font-medium mb-1 block">Title *</label>
          <Input value={form?.title ?? ''} onChange={(e) => handleChange('title', e.target.value)} placeholder="Product title" required />
        </div>
        <div>
          <label className="text-sm font-medium mb-1 block">Short Description</label>
          <Input value={form?.shortDescription ?? ''} onChange={(e) => handleChange('shortDescription', e.target.value)} placeholder="Brief summary" />
        </div>
        <div>
          <label className="text-sm font-medium mb-1 block">Full Description</label>
          <textarea
            value={form?.description ?? ''}
            onChange={(e) => handleChange('description', e.target.value)}
            placeholder="Detailed product description"
            rows={5}
            className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
          />
        </div>
      </div>

      <div className="bg-card rounded-lg p-6 space-y-4" style={{ boxShadow: 'var(--shadow-md)' }}>
        <h2 className="font-display font-semibold">Pricing & Category</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium mb-1 block">Price ($) *</label>
            <Input type="number" step="0.01" min="0" value={form?.price ?? ''} onChange={(e) => handleChange('price', e.target.value)} placeholder="29.99" required />
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Compare At Price ($)</label>
            <Input type="number" step="0.01" min="0" value={form?.compareAtPrice ?? ''} onChange={(e) => handleChange('compareAtPrice', e.target.value)} placeholder="49.99" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium mb-1 block">Category</label>
            <select value={form?.category ?? ''} onChange={(e) => handleChange('category', e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
              {PRODUCT_CATEGORIES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Product Type</label>
            <select value={form?.productType ?? ''} onChange={(e) => handleChange('productType', e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
              {PRODUCT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input type="checkbox" checked={form?.featured ?? false} onChange={(e) => handleChange('featured', e.target.checked)} className="rounded" />
            Featured Product
          </label>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input type="checkbox" checked={form?.active ?? true} onChange={(e) => handleChange('active', e.target.checked)} className="rounded" />
            Active (visible in store)
          </label>
        </div>
      </div>

      <div className="bg-card rounded-lg p-6 space-y-4" style={{ boxShadow: 'var(--shadow-md)' }}>
        <h2 className="font-display font-semibold">Media</h2>
        <div>
          <label className="text-sm font-medium mb-1 block">Product Image URL</label>
          <Input value={form?.imageUrl ?? ''} onChange={(e) => handleChange('imageUrl', e.target.value)} placeholder="https://i.ytimg.com/vi/v29Q9rWScMs/maxresdefault.jpg" />
          <div className="mt-2">
            <label className="cursor-pointer">
              <Button type="button" variant="outline" size="sm" className="gap-2" disabled={uploading} asChild>
                <span><Upload className="h-4 w-4" /> {uploading ? 'Uploading...' : 'Upload Image'}</span>
              </Button>
              <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
            </label>
          </div>
        </div>
      </div>

      <div className="bg-card rounded-lg p-6 space-y-4" style={{ boxShadow: 'var(--shadow-md)' }}>
        <h2 className="font-display font-semibold">Digital Product File</h2>
        <div>
          <label className="cursor-pointer">
            <Button type="button" variant="outline" className="gap-2" disabled={uploading} asChild>
              <span><Upload className="h-4 w-4" /> {uploading ? 'Uploading...' : 'Upload Product File'}</span>
            </Button>
            <input type="file" className="hidden" onChange={handleFileUpload} />
          </label>
          {form?.fileName && (
            <p className="text-sm text-muted-foreground mt-2">Current file: {form.fileName} ({form?.fileSize ? `${(parseInt(form.fileSize) / 1024 / 1024).toFixed(1)} MB` : ''})</p>
          )}
        </div>
      </div>

      <div className="flex gap-3">
        <Button type="submit" className="gap-2" loading={loading}>
          <Save className="h-4 w-4" /> {isEdit ? 'Update Product' : 'Create Product'}
        </Button>
        <Link href="/admin/products">
          <Button type="button" variant="outline">Cancel</Button>
        </Link>
      </div>
    </form>
  );
}
