'use client';

import { ProductForm } from '../_components/product-form';

export default function NewProductPage() {
  return (
    <div className="max-w-[800px]">
      <h1 className="font-display text-2xl font-bold tracking-tight mb-6">Add New Product</h1>
      <ProductForm />
    </div>
  );
}
