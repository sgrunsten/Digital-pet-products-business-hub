'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatPrice, getCategoryLabel } from '@/lib/constants';
import { Plus, Edit, Trash2, Star, Package, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function AdminProductsPage() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProducts = () => {
    fetch('/api/products?active=all')
      .then((r) => r.json())
      .then((d) => setProducts(d ?? []))
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchProducts(); }, []);

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to deactivate this product?')) return;
    try {
      await fetch(`/api/products/${id}`, { method: 'DELETE' });
      toast.success('Product deactivated');
      fetchProducts();
    } catch {
      toast.error('Failed to delete');
    }
  };

  const toggleActive = async (id: string, active: boolean) => {
    try {
      await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: !active }),
      });
      toast.success(active ? 'Product hidden' : 'Product visible');
      fetchProducts();
    } catch {
      toast.error('Failed to update');
    }
  };

  return (
    <div className="space-y-6 max-w-[1200px]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Products</h1>
          <p className="text-muted-foreground">{products?.length ?? 0} total products</p>
        </div>
        <Link href="/admin/products/new">
          <Button className="gap-2"><Plus className="h-4 w-4" /> Add Product</Button>
        </Link>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1,2,3].map((i) => <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />)}
        </div>
      ) : (products?.length ?? 0) === 0 ? (
        <div className="text-center py-20">
          <Package className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="font-display text-xl font-semibold mb-2">No products yet</h3>
          <Link href="/admin/products/new">
            <Button className="gap-2"><Plus className="h-4 w-4" /> Create your first product</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {(products ?? []).map((p: any, i: number) => (
            <motion.div
              key={p?.id ?? i}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              className={`bg-card rounded-lg p-4 flex items-center gap-4 ${!p?.active ? 'opacity-60' : ''}`}
              style={{ boxShadow: 'var(--shadow-sm)' }}
            >
              <div className="relative w-16 h-12 rounded-md overflow-hidden bg-muted flex-shrink-0">
                {p?.imageUrl ? (
                  <Image src={p.imageUrl} alt={p?.title ?? ''} fill className="object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center"><Package className="h-5 w-5 text-muted-foreground/30" /></div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium truncate">{p?.title ?? 'Untitled'}</h3>
                  {p?.featured && <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-500 flex-shrink-0" />}
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Badge variant="secondary" className="text-xs">{getCategoryLabel(p?.category ?? '')}</Badge>
                  <span>{p?.downloadCount ?? 0} sales</span>
                </div>
              </div>
              <span className="font-display font-bold">{formatPrice(p?.price ?? 0)}</span>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon-sm" onClick={() => toggleActive(p?.id, p?.active)}>
                  {p?.active ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
                <Link href={`/admin/products/${p?.id}`}>
                  <Button variant="ghost" size="icon-sm"><Edit className="h-4 w-4" /></Button>
                </Link>
                <Button variant="ghost" size="icon-sm" onClick={() => handleDelete(p?.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
