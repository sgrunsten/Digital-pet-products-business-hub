import { SocialStudioClient } from '../_components/social-studio-client';

export default function AdminSocialPage() {
  return <SocialStudioClient />;
}
