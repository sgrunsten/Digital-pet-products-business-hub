import { prisma } from '@/lib/db';
import { notFound } from 'next/navigation';
import { OrderConfirmationClient } from './_components/order-confirmation-client';
import { stripe } from '@/lib/stripe';

export const dynamic = 'force-dynamic';

export default async function OrderConfirmationPage({
  params,
  searchParams,
}: {
  params: { orderNumber: string };
  searchParams: { session_id?: string };
}) {
  let order = await prisma.order.findUnique({
    where: { orderNumber: params?.orderNumber ?? '' },
    include: {
      items: { include: { product: { select: { title: true, imageUrl: true, category: true } } } },
      downloads: true,
    },
  });

  if (!order) return notFound();

  // If order is still pending and we have a session_id, verify payment with Stripe
  if (order.status === 'pending' && searchParams?.session_id) {
    try {
      const session = await stripe.checkout.sessions.retrieve(searchParams.session_id);
      if (session?.payment_status === 'paid') {
        // Mark order completed
        await prisma.order.update({
          where: { id: order.id },
          data: {
            status: 'completed',
            stripePaymentId: (session?.payment_intent as string) ?? null,
          },
        });

        // Create downloads if none exist yet
        if ((order.downloads?.length ?? 0) === 0) {
          const downloadPromises = (order?.items ?? []).map((item: any) =>
            prisma.download.create({
              data: {
                token: `${order!.orderNumber}-${item?.productId ?? ''}-${Math.random().toString(36).substring(2, 10)}`,
                orderId: order!.id,
                productId: item?.productId ?? '',
                expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
                maxDownloads: 5,
              },
            })
          );
          await Promise.all(downloadPromises);

          // Update product download counts
          for (const item of order?.items ?? []) {
            await prisma.product.update({
              where: { id: item?.productId ?? '' },
              data: { downloadCount: { increment: 1 } },
            });
          }
        }

        // Re-fetch order with updated data
        order = await prisma.order.findUnique({
          where: { orderNumber: params?.orderNumber ?? '' },
          include: {
            items: { include: { product: { select: { title: true, imageUrl: true, category: true } } } },
            downloads: true,
          },
        });
        if (!order) return notFound();
      }
    } catch (err) {
      console.error('Stripe session verification error:', err);
    }
  }

  return <OrderConfirmationClient order={JSON.parse(JSON.stringify(order))} />;
}
