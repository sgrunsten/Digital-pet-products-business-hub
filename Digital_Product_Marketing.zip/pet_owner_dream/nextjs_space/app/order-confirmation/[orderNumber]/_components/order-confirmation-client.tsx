'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { Button } from '@/components/ui/button';
import { formatPrice, getCategoryLabel } from '@/lib/constants';
import { CheckCircle, Download, ArrowRight, Mail } from 'lucide-react';

export function OrderConfirmationClient({ order }: { order: any }) {
  const handleDownload = (token: string) => {
    const link = document.createElement('a');
    link.href = `/api/download/${token}`;
    link.click();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="max-w-[700px] mx-auto px-4 py-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-8"
          >
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h1 className="font-display text-3xl font-bold tracking-tight mb-2">Order Confirmed!</h1>
            <p className="text-muted-foreground">Thank you for your purchase. Your digital products are ready for download.</p>
          </motion.div>

          <div className="bg-card rounded-lg p-6 mb-6" style={{ boxShadow: 'var(--shadow-md)' }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Order Number</p>
                <p className="font-mono font-semibold">{order?.orderNumber ?? ''}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="font-display font-bold text-lg text-primary">{formatPrice(order?.total ?? 0)}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Mail className="h-4 w-4" />
              Confirmation sent to {order?.customerEmail ?? ''}
            </div>
          </div>

          <div className="bg-card rounded-lg p-6 mb-6" style={{ boxShadow: 'var(--shadow-md)' }}>
            <h2 className="font-display text-lg font-semibold mb-4">Your Downloads</h2>
            <div className="space-y-3">
              {(order?.items ?? []).map((item: any, idx: number) => {
                const dl = (order?.downloads ?? []).find((d: any) => d?.productId === item?.productId);
                return (
                  <div key={item?.id ?? idx} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div>
                      <p className="font-medium">{item?.product?.title ?? 'Product'}</p>
                      <p className="text-xs text-muted-foreground">{getCategoryLabel(item?.product?.category ?? '')}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{formatPrice(item?.price ?? 0)}</span>
                      {dl?.token && (
                        <Button size="sm" variant="outline" className="gap-1" onClick={() => handleDownload(dl.token)}>
                          <Download className="h-3.5 w-3.5" /> Download
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="text-center">
            <Link href="/products">
              <Button size="lg" className="gap-2">
                Continue Shopping <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
