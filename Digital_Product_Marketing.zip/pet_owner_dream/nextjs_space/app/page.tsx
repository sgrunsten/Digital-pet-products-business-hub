import { prisma } from '@/lib/db';
import { HomeClient } from './_components/home-client';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const [featured, latest, categories] = await Promise.all([
    prisma.product.findMany({
      where: { active: true, featured: true },
      take: 4,
      orderBy: { createdAt: 'desc' },
      select: { id: true, title: true, slug: true, price: true, compareAtPrice: true, imageUrl: true, category: true, featured: true, shortDescription: true },
    }),
    prisma.product.findMany({
      where: { active: true },
      take: 8,
      orderBy: { createdAt: 'desc' },
      select: { id: true, title: true, slug: true, price: true, compareAtPrice: true, imageUrl: true, category: true, featured: true, shortDescription: true },
    }),
    prisma.product.groupBy({
      by: ['category'],
      where: { active: true },
      _count: { id: true },
    }),
  ]);

  return <HomeClient featured={featured ?? []} latest={latest ?? []} categories={categories ?? []} />;
}
