'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCart } from '@/lib/cart-context';
import { formatPrice } from '@/lib/constants';
import { CreditCard, Tag, Lock, ShieldCheck, Mail, User } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function CheckoutPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { items, subtotal, clearCart } = useCart();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [discountCode, setDiscountCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [discountApplied, setDiscountApplied] = useState('');
  const [loading, setLoading] = useState(false);
  const [applyingDiscount, setApplyingDiscount] = useState(false);

  useEffect(() => {
    if (searchParams?.get('cancelled') === 'true') {
      toast.error('Payment was cancelled. You can try again when ready.');
    }
  }, [searchParams]);

  const total = Math.max(0, (subtotal ?? 0) - discount);

  const handleApplyDiscount = async () => {
    if (!discountCode?.trim()) return;
    setApplyingDiscount(true);
    try {
      const res = await fetch('/api/discount/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: discountCode, subtotal }),
      });
      const data = await res.json();
      if (res.ok && data?.valid) {
        setDiscount(data?.discountAmount ?? 0);
        setDiscountApplied(discountCode);
        toast.success(`Discount applied! You save ${formatPrice(data?.discountAmount ?? 0)}`);
      } else {
        toast.error(data?.error ?? 'Invalid discount code');
      }
    } catch {
      toast.error('Failed to apply discount');
    } finally {
      setApplyingDiscount(false);
    }
  };

  const handleCheckout = async () => {
    if (!email?.trim()) { toast.error('Email is required'); return; }
    if ((items?.length ?? 0) === 0) { toast.error('Cart is empty'); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          name: name || null,
          items: (items ?? []).map((i: any) => ({ productId: i?.id, quantity: 1, price: i?.price ?? 0 })),
          discountCode: discountApplied || null,
        }),
      });
      const data = await res.json();
      if (res.ok && data?.url) {
        clearCart?.();
        window.location.href = data.url;
      } else {
        toast.error(data?.error ?? 'Checkout failed');
      }
    } catch {
      toast.error('Checkout failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if ((items?.length ?? 0) === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <SiteHeader />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="font-display text-2xl font-bold mb-4">Your cart is empty</h2>
            <Button onClick={() => router.push('/products')}>Browse Products</Button>
          </div>
        </main>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="max-w-[900px] mx-auto px-4 py-8">
          <h1 className="font-display text-3xl font-bold tracking-tight mb-8">Checkout</h1>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            {/* Form */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="lg:col-span-3 space-y-6">
              <div className="bg-card rounded-lg p-6" style={{ boxShadow: 'var(--shadow-md)' }}>
                <h2 className="font-display text-lg font-semibold mb-4">Contact Information</h2>
                <div className="space-y-4">
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="email"
                      placeholder="Email address *"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="text"
                      placeholder="Name (optional)"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-card rounded-lg p-6" style={{ boxShadow: 'var(--shadow-md)' }}>
                <h2 className="font-display text-lg font-semibold mb-4">Discount Code</h2>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="text"
                      placeholder="Enter discount code"
                      value={discountCode}
                      onChange={(e) => setDiscountCode(e.target.value.toUpperCase())}
                      className="pl-10"
                    />
                  </div>
                  <Button variant="outline" onClick={handleApplyDiscount} loading={applyingDiscount}>Apply</Button>
                </div>
                {discountApplied && (
                  <p className="text-sm text-green-600 mt-2">Code &ldquo;{discountApplied}&rdquo; applied &ndash; saving {formatPrice(discount)}</p>
                )}
              </div>

              <div className="bg-card rounded-lg p-6" style={{ boxShadow: 'var(--shadow-md)' }}>
                <div className="flex items-center gap-2 mb-4">
                  <CreditCard className="h-5 w-5 text-primary" />
                  <h2 className="font-display text-lg font-semibold">Payment</h2>
                </div>
                <div className="bg-muted/50 rounded-lg p-4 text-center">
                  <ShieldCheck className="h-8 w-8 text-primary mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">You&apos;ll be securely redirected to Stripe to complete your payment.</p>
                  <p className="text-xs text-muted-foreground mt-1">All card details are handled by Stripe &ndash; we never see your card info.</p>
                </div>
              </div>

              <Button size="lg" className="w-full gap-2" onClick={handleCheckout} loading={loading}>
                <ShieldCheck className="h-5 w-5" /> Pay {formatPrice(total)} &ndash; Secure Checkout
              </Button>
            </motion.div>

            {/* Summary */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="lg:col-span-2">
              <div className="bg-card rounded-lg p-6 sticky top-24" style={{ boxShadow: 'var(--shadow-md)' }}>
                <h2 className="font-display text-lg font-semibold mb-4">Order Summary</h2>
                <div className="space-y-3 mb-4">
                  {(items ?? []).map((item: any) => (
                    <div key={item?.id} className="flex justify-between text-sm">
                      <span className="truncate mr-2">{item?.title ?? 'Item'}</span>
                      <span className="font-medium">{formatPrice(item?.price ?? 0)}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t border-border pt-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>{formatPrice(subtotal ?? 0)}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-sm text-green-600">
                      <span>Discount</span>
                      <span>-{formatPrice(discount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-display font-bold text-lg pt-2 border-t border-border">
                    <span>Total</span>
                    <span className="text-primary">{formatPrice(total)}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
