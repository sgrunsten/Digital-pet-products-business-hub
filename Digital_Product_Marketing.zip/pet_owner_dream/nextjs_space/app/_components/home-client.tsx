'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { ProductCard } from '@/components/product-card';
import { NewsletterForm } from '@/components/newsletter-form';
import { Button } from '@/components/ui/button';
import { ArrowRight, BookOpen, GraduationCap, Layout, Smartphone, Palette, Video, Headphones, Sparkles } from 'lucide-react';
import { getCategoryLabel } from '@/lib/constants';

const categoryIcons: Record<string, any> = {
  ebooks: BookOpen,
  courses: GraduationCap,
  templates: Layout,
  software: Smartphone,
  graphics: Palette,
  videos: Video,
  audio: Headphones,
};

interface Props {
  featured: any[];
  latest: any[];
  categories: { category: string; _count: { id: number } }[];
}

function AnimatedSection({ children, className }: { children: React.ReactNode; className?: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-50px' });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6 }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function HomeClient({ featured, latest, categories }: Props) {
  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-secondary/10">
        <div className="absolute inset-0 z-0">
          <Image
            src="https://cdn.abacus.ai/images/a885eca4-cad9-4d73-acb4-3c414f05c13f.png"
            alt="Happy pets in a cozy home"
            fill
            className="object-cover opacity-20"
            priority
          />
        </div>
        <div className="relative z-10 max-w-[1200px] mx-auto px-4 py-20 md:py-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-4 py-1.5 text-sm font-medium mb-6">
              <Sparkles className="h-4 w-4" /> Premium Digital Products
            </div>
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-4">
              Everything Your <span className="text-primary">Pet</span> Deserves
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-lg">
              Discover curated ebooks, courses, templates, and tools crafted exclusively for dedicated pet owners.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/products">
                <Button size="lg" className="gap-2">
                  Browse Products <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/products?category=ebooks">
                <Button size="lg" variant="outline" className="gap-2">
                  <BookOpen className="h-4 w-4" /> View Ebooks
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      {(categories?.length ?? 0) > 0 && (
        <AnimatedSection className="max-w-[1200px] mx-auto px-4 py-16">
          <h2 className="font-display text-2xl md:text-3xl font-bold tracking-tight text-center mb-10">Browse by Category</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-4">
            {(categories ?? []).map((cat: any) => {
              const Icon = categoryIcons[cat?.category] ?? Sparkles;
              return (
                <Link key={cat?.category} href={`/products?category=${cat?.category ?? ''}`}>
                  <div className="bg-card rounded-lg p-4 text-center transition-all hover:shadow-lg hover:-translate-y-1 cursor-pointer" style={{ boxShadow: 'var(--shadow-sm)' }}>
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <p className="text-sm font-medium">{getCategoryLabel(cat?.category ?? '')}</p>
                    <p className="text-xs text-muted-foreground mt-1">{cat?._count?.id ?? 0} items</p>
                  </div>
                </Link>
              );
            })}
          </div>
        </AnimatedSection>
      )}

      {/* Featured Products */}
      {(featured?.length ?? 0) > 0 && (
        <section className="bg-muted/30">
          <AnimatedSection className="max-w-[1200px] mx-auto px-4 py-16">
            <div className="flex items-center justify-between mb-8">
              <h2 className="font-display text-2xl md:text-3xl font-bold tracking-tight">Featured Products</h2>
              <Link href="/products">
                <Button variant="ghost" className="gap-1">View All <ArrowRight className="h-4 w-4" /></Button>
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {(featured ?? []).map((product: any, i: number) => (
                <ProductCard key={product?.id ?? i} product={product} index={i} />
              ))}
            </div>
          </AnimatedSection>
        </section>
      )}

      {/* Latest Products */}
      <AnimatedSection className="max-w-[1200px] mx-auto px-4 py-16">
        <div className="flex items-center justify-between mb-8">
          <h2 className="font-display text-2xl md:text-3xl font-bold tracking-tight">Latest Products</h2>
          <Link href="/products">
            <Button variant="ghost" className="gap-1">See All <ArrowRight className="h-4 w-4" /></Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {(latest ?? []).map((product: any, i: number) => (
            <ProductCard key={product?.id ?? i} product={product} index={i} />
          ))}
        </div>
      </AnimatedSection>

      {/* Newsletter */}
      <NewsletterForm />

      <SiteFooter />
    </div>
  );
}
