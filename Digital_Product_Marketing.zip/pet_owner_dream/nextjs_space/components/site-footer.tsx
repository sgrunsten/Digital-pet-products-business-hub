'use client';

import Link from 'next/link';
import { PawPrint, Heart } from 'lucide-react';

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-muted/30">
      <div className="max-w-[1200px] mx-auto px-4 py-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <Link href="/" className="flex items-center gap-2 font-display font-bold text-lg">
            <PawPrint className="h-6 w-6 text-primary" />
            <span>Pet Owners Dream</span>
          </Link>
          <nav className="flex items-center gap-6 text-sm text-muted-foreground">
            <Link href="/products" className="hover:text-foreground transition-colors">Shop</Link>
            <Link href="/cart" className="hover:text-foreground transition-colors">Cart</Link>
            <Link href="/admin/login" className="hover:text-foreground transition-colors">Admin</Link>
          </nav>
        </div>
        <div className="mt-8 pt-6 border-t border-border text-center text-sm text-muted-foreground">
          <p className="flex items-center justify-center gap-1">
            Made with <Heart className="h-3.5 w-3.5 text-primary fill-primary" /> for pet lovers everywhere
          </p>
        </div>
      </div>
    </footer>
  );
}
