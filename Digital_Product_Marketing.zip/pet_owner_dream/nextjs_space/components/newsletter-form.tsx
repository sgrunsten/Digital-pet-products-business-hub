'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Mail, PawPrint } from 'lucide-react';
import { toast } from 'sonner';

export function NewsletterForm() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    try {
      const res = await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (res.ok) {
        toast.success('Welcome to the pack! 🐾');
        setEmail('');
      } else {
        toast.error(data?.error ?? 'Something went wrong');
      }
    } catch {
      toast.error('Failed to subscribe');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="bg-primary/5 py-16">
      <div className="max-w-[600px] mx-auto px-4 text-center">
        <PawPrint className="h-10 w-10 text-primary mx-auto mb-4" />
        <h2 className="font-display text-2xl md:text-3xl font-bold tracking-tight mb-2">Join Our Pet-Loving Community</h2>
        <p className="text-muted-foreground mb-6">Get exclusive deals, new product alerts, and pet care tips delivered to your inbox.</p>
        <form onSubmit={handleSubmit} className="flex gap-2 max-w-md mx-auto">
          <div className="relative flex-1">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10"
              required
            />
          </div>
          <Button type="submit" loading={loading}>Subscribe</Button>
        </form>
      </div>
    </section>
  );
}
