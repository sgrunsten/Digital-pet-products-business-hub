'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useSession, signOut } from 'next-auth/react';
import { useCart } from '@/lib/cart-context';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Menu, X, PawPrint, Search, LayoutDashboard, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function SiteHeader() {
  const { data: session } = useSession() || {};
  const { itemCount } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinks = [
    { href: '/products', label: 'Shop' },
    { href: '/products?category=ebooks', label: 'Ebooks' },
    { href: '/products?category=courses', label: 'Courses' },
    { href: '/products?category=templates', label: 'Templates' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-background/80 backdrop-blur-md border-b border-border/50">
      <div className="max-w-[1200px] mx-auto flex items-center justify-between px-4 h-16">
        <Link href="/" className="flex items-center gap-2 font-display font-bold text-xl tracking-tight">
          <PawPrint className="h-7 w-7 text-primary" />
          <span>Pet Owners <span className="text-primary">Dream</span></span>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href}>
              <Button variant="ghost" size="sm">{link.label}</Button>
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link href="/products">
            <Button variant="ghost" size="icon" className="hidden md:flex">
              <Search className="h-5 w-5" />
            </Button>
          </Link>
          <Link href="/cart" className="relative">
            <Button variant="ghost" size="icon">
              <ShoppingCart className="h-5 w-5" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                  {itemCount}
                </span>
              )}
            </Button>
          </Link>
          {session?.user && (
            <>
              <Link href="/admin">
                <Button variant="ghost" size="icon" className="hidden md:flex">
                  <LayoutDashboard className="h-5 w-5" />
                </Button>
              </Link>
              <Button variant="ghost" size="icon" className="hidden md:flex" onClick={() => signOut?.()}>
                <LogOut className="h-5 w-5" />
              </Button>
            </>
          )}
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden border-t border-border overflow-hidden bg-background"
          >
            <nav className="flex flex-col p-4 gap-1">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href} onClick={() => setMobileOpen(false)}>
                  <Button variant="ghost" className="w-full justify-start">{link.label}</Button>
                </Link>
              ))}
              {session?.user && (
                <>
                  <Link href="/admin" onClick={() => setMobileOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start"><LayoutDashboard className="h-4 w-4 mr-2" /> Dashboard</Button>
                  </Link>
                  <Button variant="ghost" className="w-full justify-start" onClick={() => { signOut?.(); setMobileOpen(false); }}>
                    <LogOut className="h-4 w-4 mr-2" /> Sign Out
                  </Button>
                </>
              )}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
