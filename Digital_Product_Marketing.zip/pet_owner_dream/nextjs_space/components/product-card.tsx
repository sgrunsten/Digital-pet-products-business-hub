'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useCart } from '@/lib/cart-context';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Star } from 'lucide-react';
import { formatPrice, getCategoryLabel } from '@/lib/constants';
import { toast } from 'sonner';

interface ProductCardProps {
  product: {
    id: string;
    title: string;
    slug: string;
    price: number;
    compareAtPrice: number | null;
    imageUrl: string | null;
    category: string;
    featured: boolean;
    shortDescription: string | null;
  };
  index?: number;
}

export function ProductCard({ product, index = 0 }: ProductCardProps) {
  const { addItem, items } = useCart();
  const isInCart = (items ?? []).some((i: any) => i?.id === product?.id);
  const discount = product?.compareAtPrice
    ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
    : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isInCart) {
      addItem({
        id: product?.id ?? '',
        title: product?.title ?? '',
        price: product?.price ?? 0,
        imageUrl: product?.imageUrl ?? null,
      });
      toast.success('Added to cart!');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.4 }}
    >
      <Link href={`/products/${product?.slug ?? ''}`} className="group block">
        <div className="bg-card rounded-lg overflow-hidden transition-all duration-300 hover:shadow-lg" style={{ boxShadow: 'var(--shadow-md)' }}>
          <div className="relative aspect-video bg-muted">
            {product?.imageUrl ? (
              <Image
                src={product.imageUrl}
                alt={product?.title ?? 'Product'}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Star className="h-12 w-12 text-muted-foreground/30" />
              </div>
            )}
            {product?.featured && (
              <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground">
                <Star className="h-3 w-3 mr-1 fill-current" /> Featured
              </Badge>
            )}
            {discount > 0 && (
              <Badge className="absolute top-3 right-3 bg-destructive text-destructive-foreground">
                -{discount}%
              </Badge>
            )}
          </div>
          <div className="p-4">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-1">
              {getCategoryLabel(product?.category ?? '')}
            </p>
            <h3 className="font-display font-semibold text-base tracking-tight line-clamp-1 group-hover:text-primary transition-colors">
              {product?.title ?? 'Untitled'}
            </h3>
            {product?.shortDescription && (
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{product.shortDescription}</p>
            )}
            <div className="flex items-center justify-between mt-3">
              <div className="flex items-baseline gap-2">
                <span className="font-display font-bold text-lg">{formatPrice(product?.price ?? 0)}</span>
                {product?.compareAtPrice && (
                  <span className="text-sm text-muted-foreground line-through">{formatPrice(product.compareAtPrice)}</span>
                )}
              </div>
              <Button
                size="sm"
                variant={isInCart ? 'secondary' : 'default'}
                onClick={handleAddToCart}
                disabled={isInCart}
              >
                <ShoppingCart className="h-4 w-4" />
                {isInCart ? 'In Cart' : 'Add'}
              </Button>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
