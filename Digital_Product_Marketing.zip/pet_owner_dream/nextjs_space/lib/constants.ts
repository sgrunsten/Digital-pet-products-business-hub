export const PRODUCT_CATEGORIES = [
  { value: 'ebooks', label: 'Ebooks', icon: 'BookOpen' },
  { value: 'courses', label: 'Online Courses', icon: 'GraduationCap' },
  { value: 'templates', label: 'Templates', icon: 'Layout' },
  { value: 'software', label: 'Software & Apps', icon: 'Smartphone' },
  { value: 'graphics', label: 'Graphics & Design', icon: 'Palette' },
  { value: 'videos', label: 'Video Content', icon: 'Video' },
  { value: 'audio', label: 'Audio Files', icon: 'Headphones' },
] as const;

export const PRODUCT_TYPES = [
  'ebook',
  'course',
  'template',
  'software',
  'graphic',
  'video',
  'audio',
] as const;

export function getCategoryLabel(value: string): string {
  const cat = PRODUCT_CATEGORIES.find((c) => c.value === value);
  return cat?.label ?? value;
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(price);
}

export const SOCIAL_PLATFORMS = [
  {
    value: 'facebook',
    label: 'Facebook',
    icon: 'Facebook',
    color: '#1877F2',
    charLimit: 63206,
    tip: 'Great for detailed posts, links, and community engagement.',
  },
  {
    value: 'instagram',
    label: 'Instagram',
    icon: 'Instagram',
    color: '#E4405F',
    charLimit: 2200,
    tip: 'Visual-first. Copy the caption & image, then post from the Instagram app.',
  },
  {
    value: 'twitter',
    label: 'X (Twitter)',
    icon: 'Twitter',
    color: '#000000',
    charLimit: 280,
    tip: 'Short & punchy. Keep it under 280 characters.',
  },
  {
    value: 'pinterest',
    label: 'Pinterest',
    icon: 'Image',
    color: '#E60023',
    charLimit: 500,
    tip: 'Perfect for product images that link back to your store.',
  },
  {
    value: 'linkedin',
    label: 'LinkedIn',
    icon: 'Linkedin',
    color: '#0A66C2',
    charLimit: 3000,
    tip: 'Professional tone works best here.',
  },
  {
    value: 'tiktok',
    label: 'TikTok',
    icon: 'Music2',
    color: '#000000',
    charLimit: 2200,
    tip: 'Use the caption as a video description. Post from the TikTok app.',
  },
] as const;

export function getPlatformLabel(value: string): string {
  const p = SOCIAL_PLATFORMS.find((s) => s.value === value);
  return p?.label ?? value;
}

// Builds a one-click share/post URL for platforms that support web sharing.
// Returns null for platforms that require manual posting (Instagram, TikTok).
export function buildShareUrl(
  platform: string,
  opts: { url?: string; text?: string; imageUrl?: string; title?: string }
): string | null {
  const url = encodeURIComponent(opts.url ?? '');
  const text = encodeURIComponent(opts.text ?? '');
  const title = encodeURIComponent(opts.title ?? opts.text ?? '');
  const image = encodeURIComponent(opts.imageUrl ?? '');
  switch (platform) {
    case 'facebook':
      return `https://www.facebook.com/sharer/sharer.php?u=${url}&quote=${text}`;
    case 'twitter':
      return `https://twitter.com/intent/tweet?text=${text}&url=${url}`;
    case 'pinterest':
      return `https://pinterest.com/pin/create/button/?url=${url}&media=${image}&description=${text}`;
    case 'linkedin':
      return `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
    default:
      return null; // instagram, tiktok — manual posting
  }
}

export function generateOrderNumber(): string {
  const prefix = 'POD';
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `${prefix}-${timestamp}-${random}`;
}
